---
name: Dr.Octopus Browser Extension
description: 录制一次，审阅后重放 —— 本地优先的网页工作流录制与智能重放扩展（Chrome/Edge MV3）
colors:
  ink: "oklch(0.205 0 0)"
  graphite: "oklch(0.145 0 0)"
  paper: "oklch(1 0 0)"
  mist: "oklch(0.97 0 0)"
  fog: "oklch(0.922 0 0)"
  ash: "oklch(0.556 0 0)"
  ring: "oklch(0.708 0 0)"
  signal-red: "oklch(0.577 0.245 27.325)"
  ledger-green: "oklch(0.62 0.17 150)"
typography:
  title:
    fontFamily: "'Microsoft YaHei UI', 'Microsoft YaHei', system-ui, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 600
    lineHeight: 1.5
  body:
    fontFamily: "'Microsoft YaHei UI', 'Microsoft YaHei', system-ui, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 400
    lineHeight: 1.5
  label:
    fontFamily: "'Microsoft YaHei UI', 'Microsoft YaHei', system-ui, sans-serif"
    fontSize: "0.75rem"
    fontWeight: 400
    lineHeight: 1.5
  mono:
    fontFamily: "ui-monospace, monospace"
    fontSize: "0.75rem"
    fontWeight: 400
    lineHeight: 1.5
  meta:
    fontFamily: "ui-monospace, monospace"
    fontSize: "0.6875rem"
    fontWeight: 400
    lineHeight: 1.5
rounded:
  sm: "6px"
  md: "8px"
  lg: "10px"
  xl: "14px"
spacing:
  sm: "8px"
  md: "12px"
  lg: "16px"
components:
  button-primary:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.paper}"
    rounded: "{rounded.lg}"
    height: "32px"
    padding: "0 10px"
  button-primary-hover:
    backgroundColor: "oklch(0.205 0 0 / 80%)"
    textColor: "{colors.paper}"
  button-outline:
    backgroundColor: "{colors.paper}"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
    height: "32px"
    padding: "0 10px"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    rounded: "{rounded.lg}"
  button-destructive:
    backgroundColor: "oklch(0.577 0.245 27.325 / 10%)"
    textColor: "{colors.signal-red}"
    rounded: "{rounded.lg}"
    height: "32px"
    padding: "0 10px"
  badge-default:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.paper}"
    rounded: "{rounded.md}"
  badge-secondary:
    backgroundColor: "{colors.mist}"
    textColor: "{colors.ink}"
    rounded: "{rounded.md}"
  card:
    backgroundColor: "{colors.paper}"
    textColor: "{colors.graphite}"
    rounded: "{rounded.xl}"
    padding: "16px"
  row-record:
    textColor: "{colors.graphite}"
    rounded: "{rounded.lg}"
    padding: "12px 8px"
---

# Design System: Dr.Octopus Browser Extension

## Overview

**Creative North Star: "The Studio Monitor"（监视器）**

这是一台别在浏览器工具栏上的小型监视器：业务用户一眼读懂连接与录制状态，控件触手可及，其余一切退到黑白灰之后。界面不说服、不表演，只在状态变化时开口——录制红点、异常标题、缺口提示是仅有的"声音"。密度优先于留白：360×600 的固定窗口里，每一像素都要么是信息，要么是操作。

美学哲学是"仪器感"而非"生产力软件感"：圆角边框与浅灰分区提供温和的结构，但没有任何装饰性渐变、插画或品牌色铺陈。已确认的反面参考：彩色营销风、整页滚动、装饰性图标与冗余常驻提示文案。

**Key Characteristics:**
- 黑白灰为唯一基调；红色只表示录制中/异常，绿色只表示瞬时成功反馈
- 固定外框：品牌栏、Tab、导航、底部操作固定，正文唯一 ScrollArea 滚动
- 两级字号（14px / 12px），层级靠字重与灰阶而非字号堆叠
- 紧凑安静的仪器控件：hover 灰阶反馈、active 下沉 1px、禁用降透明
- 诚实呈现：缺口、部分保存、失败原因如实表达，不以成功态掩盖

## Colors

色板是一套纯灰阶仪器刻度，仅有两枚彩色信号灯。

### Primary
- **Ink 墨色**（frontmatter `colors.ink`）：主按钮、默认 Badge、品牌强调的唯一深色。黑色主按钮是已确认的视觉承诺。

### Neutral
- **Graphite 石墨**：正文与标题文字色（浅色模式）。
- **Paper 纸白**：Popup 与卡片背景；深色模式反转为 Graphite 级深色底。
- **Mist 薄雾**：浅灰分区——secondary/muted/accent 共用，用于卡片内信息块、Badge 底、hover 反馈。
- **Fog 雾灰**：边框与输入框描边；细线圆角边框是结构的主要来源。
- **Ash 灰烬**：辅助文字（说明、时间、计数）与未选中图标。
- **Ring 灰环**：焦点环与 outline，保证键盘可见性。

### Signal
- **Signal Red 信号红**（frontmatter `colors.signal-red`）：仅用于录制中状态点、错误/异常与 destructive 操作。
- **Ledger Green 账面绿**（frontmatter `colors.ledger-green`）：仅用于瞬时成功反馈（如复制成功对勾，约 1.5 秒后还原）。

### Named Rules
**The Two Signals Rule（双信号灯规则）。** 全界面只有红与绿两枚彩色信号：红 = 录制中或异常，绿 = 瞬时成功确认。其余一切——包括品牌——保持灰阶。新颜色进入系统前必须先回答"它是什么信号"。

**The Dark Mirror Rule（暗色镜像规则）。** 深色模式是同一套灰阶的镜像反转（Paper↔Graphite 底、Ink↔浅主色），跟随 `prefers-color-scheme`，不引入第二套彩色主题；注入页面的 Shadow Root 自带中性 token，不继承站点颜色。

## Typography

**Body/Display Font:** Microsoft YaHei UI（回退 Microsoft YaHei → system-ui），Popup 与 Shadow Root 统一使用，匹配 zh-CN 业务用户的系统阅读习惯。
**Mono Font:** ui-monospace（回退系统 mono），仅用于错误码、方法名等诊断文本。

**Character:** 系统 CJK 无衬线，零字距花活；层级由字重（600 标题 / 400 正文）与灰阶（Graphite/Ash）承担，而非字号堆叠。时间与计数一律 `tabular-nums`，让跳动的计时器不抖动。

### Hierarchy
- **Title**（600，14px，1.5）：品牌名、卡片标题、NavigationBar 页面标题、小节标题（如"最近录制"）。
- **Body**（400，14px，1.5）：一切正文、按钮、列表行、表单标签。
- **Label**（400，12px，1.5）：辅助说明、时间、计数、页脚元信息；一律配 Ash。
- **Mono**（400，12px，1.5）：错误码与诊断字段，可换行不断词（`break-all`）。
- **Meta**（400，11px，mono）：仅安装实例这类截断元信息标识码（连接页 footer），不参与常规文字层级。

### Named Rules
**The Two Sizes Rule（两级字号规则）。** Popup 常规文字只有 14px 与 12px 两级字号；11px 是 meta 角色，仅属于安装实例类截断标识码。需要更强层级时，先加字重，再降灰阶，不许加第三级正文字号。

## Layout

**固定窗口仪器。** Popup 是 360px 宽、600px 高的固定窗口（`max-h-dvh` 兜底短屏），`html/body` 永不滚动，外边距为零。

**固定外框 + 单滚动区（已批准并实施的布局契约）：** `ExtensionPopup` 顶层只拥有品牌栏、Tab 容器与各功能页；连接 Tab 排第一且每次打开默认选中，顺序为 连接 / 录制 / 工作流。业务页通过应用级 `PopupPage` 组合：可选导航/工具区（header）、正文、底部操作区（footer）。NavigationBar、搜索框、底部按钮固定在 ScrollArea 之外；正文使用共享 ScrollArea（`flex-1` + `min-h-0` 的确定高度链），无溢出时不显示滚动条。禁止叠加第二个原生滚动容器，禁止为单页设置孤立固定高度。

**间距节奏：** 页面 padding 16px，卡片/分区主间距 16px，卡内分组 12px，行内与图标-文字间距 8px。页脚 footer 以 `border-t` 与正文分隔。

**NavigationBar（子页导航契约）：** 左侧固定尺寸 ghost 返回图标（`aria-label` + 原生 `title`）、中间标题（truncate）、右侧状态/操作槽；顶级页面不传返回。标题栏与内容间以 `border-b` 分隔。

**响应式 = 短屏耐受：** 内容超出可用高度时只有正文滚动，导航、搜索与底部操作始终可达；注入页面的浮条限制在可视区内，拖动时不触发页面业务操作。

### Named Rules
**The One Viewport Rule（单视口规则）。** 任一时刻 Popup 内只有一个滚动视口——正文的共享 ScrollArea。滚动位置的保存与恢复绑定真实 viewport（按搜索关键词等 scrollKey 重置），不依赖外层 div。

## Elevation & Depth

**内部扁平，浮层才有投影（已确认的层级哲学）。** Popup 内部的层级完全由边框（Fog 细线）与灰阶色调分层（Paper 底 / Mist 分区）表达，卡片无投影。唯一允许投影的是浮于网页之上的覆盖层——录制浮条使用 `shadow-lg`，把它从任意站点背景上"抬"出来。

### Shadow Vocabulary
- **Overlay lift**（`box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)`）：仅用于注入页面的录制浮条等覆盖层。

### Named Rules
**The Flat Interior Rule（内部扁平规则）。** Popup 内任何卡片、列表、表单不添加投影；需要分层时先边框、再 Mist 底。投影是"我浮在你的页面上"的声明，Popup 没有这句话要说。

## Shapes

温和的圆角仪器面板：基准半径 10px（lg），卡片与大容器 14px（xl，如品牌图标瓦片、记录列表容器、录制浮条），输入与小控件 8px（md），最小芯片 6px（sm）。所有分区以 1px Fog 细线描边，不用分割线阴影。录制状态点是唯一的圆形元素（8px 圆点），与满屏圆角矩形形成信号对比。

## Components

### Buttons
紧凑安静的仪器控件：提交类动作实心 Ink 底，其余退为描边或幽灵。
- **Shape:** 圆角矩形（lg / 10px），默认高度 32px，sm 28px，icon-sm 28×28。
- **Primary（default）:** Ink 底 + Paper 字（`bg-primary`），hover 降 80% 不透明。用于开始录制、停止保存、保存、加载更多等真实提交动作。
- **Outline:** Paper 底 + Fog 描边，hover 落 Mist 底。用于暂停/继续、重连旁的次操作。
- **Ghost:** 透明底，hover 落 Mist。用于返回、拖动把手、复制、查看全部等导航/工具动作；图标按钮必须带可访问名称；Popup 标题栏/导航栏的简短操作提示统一用原生 `title`，不再包裹 Tooltip。
- **Destructive:** 10% Signal Red 底 + Signal Red 字，用于删除等不可逆操作，且必须保留确认步骤（页脚内联 Alert 确认，非模态）。
- **States:** `active:translate-y-px` 的 1px 下沉是唯一"手感"；禁用 = 50% 透明且不可点；focus-visible 出 Ring 灰环 + 3px 半透明环。
- **Icons:** 细线 Lucide 图标（默认 16px，sm 14px），`data-icon="inline-start/end"` 参与间距；录制入口图标固定为 `MousePointerClick`，不使用空心圆或视频录制图标。

### Badges
- **Default（Ink 底）:** 健康/正向状态——已连接、工具链就绪；配 CircleCheck 图标。
- **Secondary（Mist 底）:** 中性或降级状态——未连接、未就绪、已保存、部分保存；未就绪配 CircleMinus，绝不把未就绪暗示为已连接或新错误。
- Badge 图标 + 文字等高同距，两种变体高度一致。

### Cards / Containers
- **Corner Style:** xl（14px），1px Fog 边框，无投影。
- **Background:** Paper；卡内信息块用 Mist（如起始页摘要、异常详情块用 Mist/50）。
- **Internal Padding:** 16px，卡内分组间距 12–16px；统一使用 `Card size="sm"`。
- **页脚操作区:** `CardFooter` 内按钮 `flex-1` 均分，主操作（实心）与次操作（outline）并排。

### Inputs / Fields
- **Style:** Fog 描边、Paper 底、md 圆角；搜索使用 InputGroup + 前置 Search 图标。
- **Field:** FieldLabel + 控件纵向堆叠，开关类（如"同时录制从当前页面打开的新标签页"）用横向 Field + Checkbox，技术范围不堆进主标签。
- **Focus:** Ring 灰环；错误文案独立 Alert/角色提示，不只变色。

### Navigation
- **Tabs（Popup 顶层）:** 连接 / 录制 / 工作流，连接第一且默认选中；未开放功能 disabled + Tooltip 说明，不渲染无效入口。
- **NavigationBar（子页）:** 见 Layout；返回恢复来源列表的筛选与滚动位置。

### Lists & Pagination（记录列表契约）
- **记录行:** 语义 `<button>` 整行可点：hover 落 Mist、active 落 accent、focus-visible 出 Ring 环，尾部 ChevronRight 由 Ash 转 Graphite；键盘 Enter/Space 可进入。只读事件行（详情步骤）不加箭头与点击样式。首页与全部列表共用同一应用级 `RecordingRow` 几何（`min-h-16`、`px-2 py-3`、名称 + 元信息 + Badge + chevron）；分隔线由列表在相邻记录行之间使用独立 `Separator`，不使用按钮上的 `border-b` 或容器 `divide-y`，避免圆角导致分隔线弯曲；保留外框与行 hover 圆角。
- **结构:** 名称（14px/500，truncate）+ 元信息（12px Ash：步数 · 日期/时间）+ 状态 Badge + chevron；`min-h-16`、独立 `Separator`、容器 xl 描边。
- **分页（已确认并实施）:** 首页最近 5 条 + "查看全部"；全部列表以（创建时间, ID）稳定游标每批 20 条，底部手动"加载更多"（不用自动无限滚动）；详情每批 50 条事件按序加载。搜索覆盖全部存储记录（不只过滤已加载），关键词变化重置游标，过期查询不得覆盖新结果。"已加载 N 条"是实际加载数，不冒充总数；加载中按钮忙碌、失败保留列表并原位置重试、无更多数据时收起加载入口。按本地日期分组（今天/昨天/日期标题，12px Ash）。

### Feedback（Empty / Loading / Error）
- **空数据:** 统一 Empty / EmptyHeader / EmptyMedia(icon) / EmptyTitle——首次空列表"暂无录制记录"（FileText 图标），搜索无结果"未找到匹配的录制"（Search 图标 + "清空搜索"操作）。
- **加载:** Skeleton 占位，不伪装成空数据。
- **失败:** Alert（destructive 变体用于读取失败）+ 重试，失败不伪装为空。
- **整理任务（2026-10-30 定向修订）:** 展示任务发起时的提供商与模型快照，不以接口域名充当模型信息；旧任务未保存时显示“未记录”。“查看校验详情”仅在输出校验失败时出现在错误 Alert 内，默认折叠，正常任务不展示。此为既有任务卡片的局部修订，保留已批准配色与布局。用户随后确认移除“检查并修复”入口及其反馈，失败区仅保留诊断，底部提供模型设置与重试整理；历史带修复按钮的实现截图不再作为该操作区域的目标。
- **异常详情块:** Mist/50 底，标题与时间同行（`justify-between`），时间短格式 + Tooltip 完整时间；错误码/方法/原因 Mono 可换行；附"历史异常，不代表当前连接状态"。

### Recording Toolbar（页面浮条 · Signature）
录制期间网页内的主要控制：Paper 底、Fog 描边、xl 圆角、shadow-lg 的可拖动浮条。组成：拖动把手（GripVertical，ghost）→ Cable 品牌图标 → 状态点（录制中 = Signal Red 圆点，暂停 = Ash 圆点）+ 状态文字 + tabular-nums 计时 → 步数/页面计数 → outline 暂停/继续 → 实心停止保存 → 收起 Chevron。收起只改变密度，不暂停采集；暂停时附"暂停期间的操作不会记录"；错误以 `role="alert"` 红字呈现。浮条钳制在可视区内，拖动不触发页面业务操作；所有图标按钮有可访问名称与 Tooltip。

### Connection Footer（Signature）
PopupPage footer 槽的固定元信息区：label/value 左右结构（扩展版本、安装实例），`border-t` 分隔，内容不足时仍沉底。安装实例 11px Mono 截断（前 8…后 4），Tooltip 给完整值；ghost 复制按钮在剪贴板写入成功后才切 Ledger Green 对勾，约 1.5 秒还原，重复点击重置计时；失败不显示对勾，给简短可访问反馈（`role="status"`）。

## Do's and Don'ts

### Do:
- **Do** 让正文独占一个共享 ScrollArea，导航/搜索/底部操作固定在视口内（360×600，短屏用 `max-h-dvh` 兜底）。
- **Do** 用 14px/12px 两级字号 + 字重 + 灰阶表达层级；时间与计数一律 `tabular-nums`。
- **Do** 提交动作用实心 Ink 按钮，删除用 destructive 并保留页脚内联确认。
- **Do** 如实标注状态：缺口、部分保存、暂停、中断各有其名；录制红点与成功绿勾是仅有的彩色。
- **Do** 给每个图标按钮可访问名称；Popup 标题栏/导航栏操作使用原生 `title`，记录行支持键盘 Enter/Space 与 focus-visible 环。
- **Do** 保留浅/深色与 reduced-motion（reduce 时全局关闭动画与过渡）。

### Don't:
- **Don't** 引入除 Signal Red / Ledger Green 之外的彩色；品牌也不铺色。
- **Don't** 给 Popup 内部卡片/列表加投影；投影只属于浮于网页的覆盖层。
- **Don't** 给只读事件行添加箭头、hover 或点击暗示；不给未开放功能渲染可点入口。
- **Don't** 用常驻提示块重复说明（"无需连接""本地保存""功能尚未开放"）；权限、敏感信息隐藏、缺口与恢复提示按需出现。
- **Don't** 让外层 body 滚动或叠加第二个滚动容器；不为单页设置孤立固定高度。
- **Don't** 把"已整理/已保存"暗示为"已审阅可运行"；停止是保存操作，不设为丢弃。
- **Don't** 直接修改 `packages/ui` 共享 shadcn 源组件——通过 props、className 或应用级包装（PopupPage、NavigationBar）定制。

---

## 视觉验收与文案弹性

- 视觉稿验收以整体配色、布局、信息层级、组件样式和交互结构为准，不逐字验收图中的文案或示例内容。除用户明确指定必须保留的文字外，可根据实际功能优化按钮、标签、说明和示例，优先通俗、简洁、准确。
- 仅有文案差异无需重新出稿或请求视觉批准，也不因此将已批准稿标为需修订。调整后检查文字长度、换行和可读性，保持整体布局；实质改变布局或交互时仍遵循根目录视觉审阅规则。
- 权限、隐私、数据保存、删除及成功/失败等文字必须忠实反映已确认的行为，不能借文案调整改变产品承诺。
- 2026-10-28 用户明确确认以上验收规则；适用于现有与后续视觉稿，不改变已有稿的审阅状态。仓库通用规则见根目录 AGENTS.md 的 Visual Acceptance and Copy Flexibility。

## 附录 A：视觉稿状态登记（唯一权威入口）

### 录制整理状态（2026-10-30 已确认实施）

用户确认录制首页、全部列表及详情仅展示“待整理 / 整理中 / 已整理”：本录制存在进行中的整理任务时优先显示“整理中”，否则根据实际存续的关联工作流显示“已整理”或“待整理”；草稿和已发布均算已整理，历史成功记录不作为产物存在的依据。此定向修订替代原录制稿的“已保存 / 部分保存”Badge，保留原列表布局及中性配色，无新增视觉稿。

详情提交按钮对应“整理为工作流 / 整理中…（禁用）/ 重新整理”；重新整理创建新草稿、保留已有工作流。失败、取消或中断后按存续产物回退，不新增失败Badge。存在产物时提供“查看工作流”，打开最近更新且仍存在的一份；全部关联产物删除后回到待整理。缺口在列表元信息单独提示、详情继续展示具体原因，不覆盖整理状态。整理中沿用中性Badge加spinner，保留reduced-motion及浅深色；其它视觉稿状态不变。

2026-10-30 局部交互补充：按用户要求，录制删除确认行右对齐，取消在左、确认删除在右。校验失败页在既有 Alert/任务布局内提供折叠详情、复制诊断与明确的「重试整理」。此前的旧录制修复入口及副本反馈已按用户决定撤下，该历史交互为 deprecated，replacement: none yet；未来迁移需另行设计。该补充沿用当前 Box、Alert、Button 与固定 footer，不改变主体视觉方向；运行截图作为验证证据，旧图像不覆盖。

### 整理历史（原布局保留，任务状态已替代）

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-history-board-v2.png](../../docs/design/browser-extension-recorder/workflow-history-board-v2.png) | superseded | 用户明确确认三屏布局并授权接入：历史列表、失败详情、进行中详情；固定历史入口、分页与重试关联 | 2026-10-31 | 引导式整理任务状态范围已被替代；未涉及的历史分页/诊断/进行中布局保留参考；replacement: [continuation-states-v2](../../docs/design/browser-extension-recorder/workflow-guided-continuation-states-v2.png) |
| [workflow-history-board-v1.png](../../docs/design/browser-extension-recorder/workflow-history-board-v1.png) | superseded | 运行态不应橙色，重试标记不应呈现为行内操作按钮 | 2026-10-30 | replacement: [v2](../../docs/design/browser-extension-recorder/workflow-history-board-v2.png) |

固定“整理历史”入口无历史也显示，不以旧失败红点常驻报警。沿用 Box、固定导航/底栏、全宽 ScrollArea 和独立 Separator；运行态中性，成功/失败使用现有语义色。每批20条、终态最多200条；记录名称和模型截断有整行可访问文本。详情绑定任务 ID，返回保留列表已加载范围及滚动。错误详情留在 Alert 内。成功可查看产物；失败/取消/中断可明确新建一次整理，重试标记为元信息，非独立行内按钮。原录制或产物删除时解释不可用。完整来源见 [提示词](../../docs/design/browser-extension-recorder/workflow-history-prompts.md)。

### 一键整理与首次发送授权（已确认实施）

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-direct-compile-v2.png](../../docs/design/browser-extension-recorder/workflow-direct-compile-v2.png) | approved | 按用户确认并要求实施的一键整理、首次 endpoint 授权和失败分类修复方案归档；保留现有控件密度/语义颜色，图内装饰不是新增要求 | 2026-10-29 | 修正 [v1](../../docs/design/browser-extension-recorder/workflow-direct-compile-v1.png)；替代“每次整理先进入设置”和所有失败统一返回设置的交互；replacement: none yet |
| [workflow-direct-compile-v1.png](../../docs/design/browser-extension-recorder/workflow-direct-compile-v1.png) | superseded | 首稿误将已保存密钥画成密码输入及重复状态行，未作为实施目标 | 2026-10-29 | [v2](../../docs/design/browser-extension-recorder/workflow-direct-compile-v2.png) |

已配置且已授权的接口直接开始整理，不预先测试模型；缺少配置进入设置；首次发送用现有 Dialog 轻量确认、展示准确 endpoint 和模型，确认后记住该接口授权，可在设置撤销。鉴权、接口/模型不存在和请求配置错误进入设置，保留录制上下文并提供保存并重试；网络/限流/超时及输出校验失败保留任务页，仅用户显式点击才重试。其它页面布局、Box、标题栏任务入口、顶部 Toast 和密钥状态继续沿用其已批准范围。来源与完整提示词见 [workflow-direct-compile-prompts.md](../../docs/design/browser-extension-recorder/workflow-direct-compile-prompts.md)。

### 全宽滚动与标题栏任务入口（已确认实施）

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [popup-box-task-toolbar-v2.png](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v2.png) | superseded | 仅“最近一次任务入口”交互被替代；Box/全宽滚动/固定外框仍为有效参考，原图保留 | 2026-10-30 | replacement: [workflow-history-board-v2](../../docs/design/browser-extension-recorder/workflow-history-board-v2.png)；前序 [v1](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v1.png) |
| [popup-box-task-toolbar-v1.png](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v1.png) | superseded | 首稿将滚动条画过固定导航，并在无溢出区域画滚动条，未作为实施目标 | 2026-10-29 | 已由 [v2](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v2.png) 纠正 |

本节是所有 Popup 页面共同外框的当前目标：外壳不设 padding；品牌、Tab、导航、正文、footer 分别使用应用级 Box；正文 Box 位于满宽 ScrollArea 内，输入框外扩焦点留在视口内部。Box 只提供默认间距，不默认增加背景/边框/圆角，不在每个字段重复嵌套。原页面稿仅保留已明确批准的内层控件、配色、业务交互范围，不能继续按旧外框裁切边界实施。任务入口已由上方整理历史 v2 替代，始终可见并固定命名；运行中显示 spinner，终态不加常驻失败红点。没有录制来源的旧连接测试不纳入历史，不删除原数据。完整来源与提示词见 [popup-box-task-toolbar-prompts.md](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-prompts.md)。

> 本附录是 browser-extension-recorder 视觉稿的权威状态登记（自 2026-10-28 起从 `docs/design/browser-extension-recorder/README.md` 迁入，README 仅保留链接）。状态规则按根目录 [AGENTS.md](../../AGENTS.md) 执行；当前是否可作为实施依据，以本表的状态和生效范围为准，历史审批、文件名和提示词中的旧记录均不能覆盖本表。所有图像为设计概念，不是已实现 UI 或验收证据。图像与提示词原件保留在 [docs/design/browser-extension-recorder/](../../docs/design/browser-extension-recorder/)。

### 双 Tab 与录制详情操作区（2026-11-01，第 1 稿已选方向）

用户最新明确：删除独立工作台/工作流/技能 Tab，只保留「连接状态」「录制重放」，连接状态排第一且默认选中。既有设置模块内容与行为不变，统一入口移到 Dr.Octopus 标题右侧。录制详情承载整理、技能目录、重放与整理历史入口。此要求取代下文旧稿中的三 Tab 与页面级设置入口，不代表本轮三份按钮排布已经批准。

| 显示顺序 / 文件 | 状态 | 范围 | 状态日期 | 原因 / replacement |
| --- | --- | --- | --- | --- |
| 1 · [recording-replay-context-actions-v1.png](../../docs/design/browser-extension-recorder/recording-replay-context-actions-v1.png) | approved | 双 Tab、全局设置、技能上下文链接与双主操作 footer | 2026-11-01 | 用户回复“1”选定；后续状态细化沿用此方向；replacement: none yet |
| 2 · [recording-replay-command-bar-v1.png](../../docs/design/browser-extension-recorder/recording-replay-command-bar-v1.png) | pending review | 双 Tab、全局设置、导航工具与单行 footer | 2026-10-31 | 新候选；replacement: none yet |
| 3 · [recording-replay-action-shelf-v1.png](../../docs/design/browser-extension-recorder/recording-replay-action-shelf-v1.png) | pending review | 双 Tab、全局设置、显式文字操作与双行 footer | 2026-10-31 | 新候选；replacement: none yet |

提示词、源文件与复核：[recording-replay-actions-prompts.md](../../docs/design/browser-extension-recorder/recording-replay-actions-prompts.md)。原图不覆盖；三份均为“已有技能”合成示例，不是运行截图。

2026-11-01 用户选择实际显示第 1 稿：导航右侧为整理历史与删除图标；“查看 SKILLS”位于技能状态行；底部为开始整理/重新整理与重放。第 2、3 稿保留为未选候选，不作为实施目标。此次确认选定布局方向，不等于首次整理、等待回答、失败、文件不可用、浅色/短窗等未展示状态均已审阅，也不构成正式 UI 实施授权。

交互要求：开始整理/重新整理调用整理 Agent 生成 Skill；整理历史沿用现有列表，从本录制进入时关联该录制，详情展示所选整理任务的 Agent 会话，不能被最新任务覆盖。查看 SKILLS 打开本地技能目录；重放先加载并校验关联技能；无可用技能时禁用并提供就近原因，不能误称已支持重放。删除录制保留原确认/删除逻辑，不删除本地技能文件；确认按钮仍居右，取消在左。设置返回时恢复原业务页，不丢表单草稿。

本轮失效范围登记：所有旧稿的第三 Tab、旧 Tab 文案与页面标题旁设置入口为 revision required；此前已 superseded/deprecated 的稿件保持退休状态，不重新启用。录制详情旧 footer 的单独删除/整理为工作流布局不再指导实施。此前已批准且不受影响的设置表单、只读步骤、黑白灰颜色、固定外框、Box/Separator/滚动边界仍保留参考。替代候选是本节三图，尚无批准替代。

### 已选方向的状态细化（2026-11-01，待审阅）

补充状态：[skill-agent-additional-states-v2.png](../../docs/design/browser-extension-recorder/skill-agent-additional-states-v2.png) — revision required，2026-11-01；用户确认按此接入，适用多选、保存失败、未知结果和短窗；替代下列 v1，replacement: none yet。[v1](../../docs/design/browser-extension-recorder/skill-agent-additional-states-v1.png) — superseded，同日；状态语义/绿色选择态不符合要求，已由用户批准的 [v2](../../docs/design/browser-extension-recorder/skill-agent-additional-states-v2.png) 替代。[提示词与来源](../../docs/design/browser-extension-recorder/skill-agent-additional-states-prompts.md)。等待及未知结果图标为静止Clock，不是正在执行动画；这是一处图标语义修正，不增加交互。

用户选择录制详情第1方向后要求继续，本组延续该布局，补充相关状态；不是重新选布局。保留连接状态/录制重放双Tab、品牌右侧设置、详情导航右侧历史/删除、技能状态行查看SKILLS、底部整理/重放。正式代码未改动。

| 文件 | 状态 | 范围 | 状态日期 | 原因 / 替代关系 |
| --- | --- | --- | --- | --- |
| [recording-replay-detail-states-v1.png](../../docs/design/browser-extension-recorder/recording-replay-detail-states-v1.png) | approved | 首次整理、技能文件不可用、删除确认 | 2026-11-01 | 基于已选方向细化；replacement: none yet |
| [skill-organizer-session-states-v2.png](../../docs/design/browser-extension-recorder/skill-organizer-session-states-v2.png) | revision required | 正在整理、Questionnaire单选、时间线失败 | 2026-11-01 | 修订[v1](../../docs/design/browser-extension-recorder/skill-organizer-session-states-v1.png)的蓝/黄状态色；replacement: none yet |
| [skill-replay-history-states-v2.png](../../docs/design/browser-extension-recorder/skill-replay-history-states-v2.png) | revision required | 浅色整理历史、重放参数提问、结果时间线 | 2026-11-01 | 修订[v1](../../docs/design/browser-extension-recorder/skill-replay-history-states-v1.png)的蓝色等待态；replacement: none yet |
| [skill-organizer-session-states-v1.png](../../docs/design/browser-extension-recorder/skill-organizer-session-states-v1.png) | superseded | 单选/运行/等待用了蓝黄颜色，不能作为配色目标 | 2026-11-01 | 修订候选[v2](../../docs/design/browser-extension-recorder/skill-organizer-session-states-v2.png)已获批准；replacement: 对应v2 |
| [skill-replay-history-states-v1.png](../../docs/design/browser-extension-recorder/skill-replay-history-states-v1.png) | superseded | 蓝色等待状态偏离现有中性色体系 | 2026-11-01 | 修订候选[v2](../../docs/design/browser-extension-recorder/skill-replay-history-states-v2.png)已获批准；replacement: 对应v2 |

[提示词、来源与复核](../../docs/design/browser-extension-recorder/skill-agent-state-refinement-prompts.md)。图中答案/预选仅为合成状态示例，不能作为默认替用户回答的依据。浅色v2“确认并继续”存在生成字形偏差，实际按该准确文案呈现，不改变交互。所有图是视觉概念，非运行验收。

#### 状态到行为的约束

| 状态 | 呈现与操作 |
| --- | --- |
| 从未整理且没有技能 | 显示尚未整理；开始整理为实心主操作，重放禁用；无关联目录时查看SKILLS禁用，不打开错误目录 |
| 已生成并实际保存 | 查看SKILLS打开关联目录；重新整理为次操作，重放为主操作；不能只凭历史成功记录认为磁盘仍可用 |
| 技能缺失/格式错误 | 就近Alert与按需详情，重放禁用；目录仍存在才可打开；重新整理不能覆盖用户手改文件 |
| 同一整理仍在运行/待答 | 入口回到该会话，不重复创建模型任务；设置返回也恢复原上下文 |
| 正在整理/运行 | 时间线显示实际工具状态与可展示进展；底部停止任务；停止不承诺撤回已派发动作 |
| 等待回答 | 当前工具问题可编辑，历史只读；稍后处理保留待答；确认并继续先保存答案，ACK后才继续 |
| 答案提交失败 | 保留表单输入，问题旁显示Alert；重试相同提交身份，不能重复写答案或启动两个Agent |
| 整理失败 | 保留先前活动，诊断在失败工具的Alert内；重试追加尝试和诊断，不覆盖失败历史 |
| 已生成、保存失败 | 展示尚未保存，提供重试保存；不重新调用模型生成、不允许把未落盘结果显示为可重放 |
| 页面动作结果未知 | 保留未知结果并停止后续业务副作用；无“重试该动作”快捷按钮，核对当前页面后才能决定继续 |
| 运行完成 | 展示实际观测，如查到订单及页面状态；不把查询成功描述成处理/付款成功 |
| 删除确认 | 维持原录制删除逻辑；取消左、destructive确认右；不顺带删除Skill文件或改造为新删除范围 |

历史列表继续使用可点击行与独立Separator；进入详情绑定显式任务/会话ID，而非全局最新任务。模型实际未返回的思考或工具记录不补造。多选、文件服务离线、保存失败、结果未知及短窗尚需独立视觉细化；这些契约不视为对应页面已获视觉批准。

### Skill 与 Agent Session（2026-11-01，已有状态候选，待审阅）

用户已确认[统一 ToolLoopAgent 方案](../../docs/architecture/browser-skill-unified-agent.md)：整理和重放均可主动调用 ask_user_question；会话参考 Claude Code 时间线，以 MessageScroller 承载，问题使用 Questionnaire，不能自由聊天。当前只保留连接状态/录制重放两个 Tab，全局设置位于品牌标题右侧，源录制保留。旧三个方向不包含此次多类型提问和重放会话，均需修订；黑白灰配色和固定外框仅保留为参考，不是整图批准。此前用户选择先技术验证/文档；本轮已恢复双 Tab 与录制详情视觉设计，见上节。会话内 Questionnaire/MessageScroller 细化稿仍未批准。

| 实际显示 / 文件 | 状态 | 适用范围 | 状态日期 | 原因 / replacement |
| --- | --- | --- | --- | --- |
| 1 · [skill-agent-session-timeline-v1.png](../../docs/design/browser-extension-recorder/skill-agent-session-timeline-v1.png) | revision required | 时间线、当前问题与动作区域需按新契约修订；配色/外框仅参考 | 2026-10-31 | Questionnaire 多类型问题与重放会话未覆盖；replacement: none yet |
| 2 · [skill-agent-session-focus-v1.png](../../docs/design/browser-extension-recorder/skill-agent-session-focus-v1.png) | revision required | 提问优先布局需改为连续会话；配色/外框仅参考 | 2026-10-31 | 用户指定 MessageScroller 时间线；replacement: none yet |
| 3 · [skill-agent-session-tools-v1.png](../../docs/design/browser-extension-recorder/skill-agent-session-tools-v1.png) | revision required | 工具/问题层级及运行语义需修订；配色/外框仅参考 | 2026-10-31 | 统一两阶段会话、多类型工具问题；replacement: none yet |

[提示词/源图/复核记录](../../docs/design/browser-extension-recorder/skill-agent-session-prompts.md)保留原件。生产思考摘要与工具状态必须来自真实会话记录；整理不能显示正在操作网页，重放可以展示真实页面工具活动。旧工作流编辑/发布稿不能作为新 Skill 页面的实施依据。

#### 新会话交互契约（待转为视觉稿）

- 固定品牌/Tab/NavigationBar，正文一个 MessageScroller；不包裹 ScrollArea。Box 内边距在消息内容内，滚动条位于最右边；footer 不参与滚动。
- 时间线按顺序展示任务、简短进展、折叠工具调用/结果、当前问题、只读用户回答、产物/运行结果。无自由输入框、全局发送按钮或快捷 prompt。
- Questionnaire 支持单选、多选、文本、邮箱、数字、日期；确认使用选择题。一个 ask 可以有最多 4 个相关字段，但始终只有一个待答调用；不固定整条 Agent 任务的问题数，不显示虚构的全局问卷进度。
- 字段归 TanStack Form，Questionnaire Root 为唯一 form；footer 的“确认并继续”关联当前 form，提交中禁用，事务 ACK 后才转换成只读答案。提交失败保留草稿，在问题附近用 Alert 显示错误。
- “稍后处理”保留原问题；“暂不提供”只有问题明确允许才显示；不把离开界面当作拒绝回答。历史答案不直接回改，避免悄悄改变已经执行的任务条件。
- running 页脚“停止任务”；waiting_user 页脚“稍后处理 / 确认并继续”；interrupted 按可恢复性提供“继续”；outcome_unknown 展示待核对原因，不能提供盲目重复动作按钮；保存失败提供重试保存，不重新整理。
- 用户上翻时不自动滚回底部；出现新内容显示回到最新入口。当前输入焦点不被流式消息抢走；相同会话重开定位待答条目，其他历史阅读位置按会话保存。
- 标题区区分“整理技能 / 运行技能”，工具行按业务语言显示，技术参数按需展开。状态不只依赖颜色；原生 title/aria-label、Separator、实心提交按钮、浅深色和 reduced-motion 规则继续有效。
- 下一轮视觉需覆盖：整理单选、重放邮箱/编号、多选、已回答继续、成功产物、失败/未知结果、短窗/浅色、技能库/详情及文件服务不可用。先出稿审阅，再接正式 UI；当前仅确认交互方向。

### 引导式整理（2026-10-31，第2方向详细状态已批准并接入）

用户同意方向：智能体按录制中的不确定性引导提问，不能自由聊天，JSON继续作为权威工作流；先开发设计文档和视觉稿，用户决策后再实施。当前仅文档与图片交付，没有业务代码改动。开发契约与待决策项见[引导式整理设计](../../docs/architecture/browser-workflow-guided-organization.md)。

| 实际显示顺序 / 文件 | 状态 | 适用范围 | 状态日期 | 原因 / replacement |
| --- | --- | --- | --- | --- |
| 1 · [workflow-guided-question-focus-v1.png](../../docs/design/browser-extension-recorder/workflow-guided-question-focus-v1.png) | superseded | 聚焦当前问题，相关步骤紧凑引用；仅提问主界面 | 2026-10-31 | 本轮未选用，未曾获批准；replacement: [已选第2稿](../../docs/design/browser-extension-recorder/workflow-guided-question-evidence-v1.png) |
| 2 · [workflow-guided-question-evidence-v1.png](../../docs/design/browser-extension-recorder/workflow-guided-question-evidence-v1.png) | superseded | 先展示相关录制，再提问；仅提问主界面 | 2026-10-31 | 用户选定的第2方向保留；已由获批细化稿承接，replacement: [question-states-v2](../../docs/design/browser-extension-recorder/workflow-guided-question-states-v2.png) |
| 3 · [workflow-guided-question-decisions-v1.png](../../docs/design/browser-extension-recorder/workflow-guided-question-decisions-v1.png) | superseded | 保留紧凑已答摘要，再提问；仅提问主界面 | 2026-10-31 | 本轮未选用，未曾获批准；replacement: [已选第2稿](../../docs/design/browser-extension-recorder/workflow-guided-question-evidence-v1.png) |

三稿不是已实现截图；完整提示词和实际显示映射见[来源记录](../../docs/design/browser-extension-recorder/workflow-guided-prompts.md)。图中选项已选仅为状态展示，不代表默认替用户回答。稿1的蓝色“补充说明”偏离当前中性色标准，选中后需细化修正。用户选定实际显示第2稿后，已批准下方两张v2细化稿；方向稿现为superseded，保留用户选择来源。第1/3稿同为superseded。实施应使用下方获批细化稿，不回退到首稿；视觉批准不等于实施授权。

历史稿受影响范围：workflow-history-board-v2的整理任务详情需增加“待回答/待保存”及回访，相关状态范围已由continuation-states-v2替代并标记superseded；历史列表布局、失败诊断布局及明确重试仍可参考。步骤详情核对的已批准布局继续适用，问答只消除已经明确解决的重复核对，不取消执行前确认。旧生成成功条件表单不应作为本提案的新实施目标；替代交互的第2方向细化状态已获视觉批准；技术契约仍按开发设计待决策项处理，没有静默更新架构基线。


#### 第2方向详细状态（已批准并接入）

2026-10-31已按用户选择细化同一方向。用户随后明确确认两张v2细化稿，现登记为approved。它们不是新的“方案1/2”；源首稿保留，按具体批准范围记录替代关系。此次确认不包含代码实施授权。

| 文件 | 状态 | 适用范围 | 状态日期 | 原因 / replacement |
| --- | --- | --- | --- | --- |
| [workflow-guided-question-states-v2.png](../../docs/design/browser-extension-recorder/workflow-guided-question-states-v2.png) | revision required | 深色、补充说明、短窗口的提问页面 | 2026-10-31 | 用户确认移除完成判断页的相关录制块；2026-10-31进一步明确Skill为维护目标，固定完成方式向导需重设计。其余黑白灰/固定外框可参考；replacement: none yet |
| [workflow-guided-continuation-states-v2.png](../../docs/design/browser-extension-recorder/workflow-guided-continuation-states-v2.png) | revision required | 稍后回访、请求失败、整理预览 | 2026-10-31 | 用户明确以本地Skill为维护入口，复杂工作流预览/编辑/发布交互需重新设计；历史恢复及固定外框可参考；replacement: none yet |
| [workflow-guided-question-states-v1.png](../../docs/design/browser-extension-recorder/workflow-guided-question-states-v1.png) | superseded | 原深色可参考；中/右滚动范围与短窗口几何不能指导实施 | 2026-10-31 | 生成偏差；replacement: [question-states-v2](../../docs/design/browser-extension-recorder/workflow-guided-question-states-v2.png)，已获用户批准 |
| [workflow-guided-continuation-states-v1.png](../../docs/design/browser-extension-recorder/workflow-guided-continuation-states-v1.png) | superseded | 原失败和预览布局可参考；历史页脚与待答/待确认配色不能指导实施 | 2026-10-31 | 生成偏差；replacement: [continuation-states-v2](../../docs/design/browser-extension-recorder/workflow-guided-continuation-states-v2.png)，已获用户批准 |

[完整提示词/来源/复核](../../docs/design/browser-extension-recorder/workflow-guided-refinement-prompts.md)。新稿只细化已选方向，模型请求上限、单会话限制、manual发布规则及图标提示仍按开发设计列为待决策；没有业务代码/模型请求改动。旧history-board-v2的任务状态范围已按用户批准由continuation-states-v2替代，未涉及区域的参考范围已在登记行注明。

### 步骤就地核对（方案 2 已批准）

2026-10-30 用户定向优化：步骤详情固定页脚的“已核对该步骤”与“执行前需再次确认”改为同一行、两端对齐，取代方案 2 原图中的两行排列；其余已批准范围继续适用。点击“确认并发布”成功后返回工作流 Tab 的列表并刷新发布状态，失败保留编辑页及错误反馈；保存草稿仍留在编辑页。此为用户明确要求的局部调整，不新增视觉稿。

用户于2026-10-30明确要求核对移至步骤详情，列表不再重复核对清单，总确认改为“已核对参数、成功条件”。来源与核对状态分开；列表采用“待核对/已核对”，模型补充来源保留在次级信息及详情。应用后列表反馈核对状态，取消不生效，相关内容修改后需重新核对。该步骤就地核对已实现并经用户人工验收；本段视觉批准不替代引导式整理的新设计审阅。

| 视觉稿 / 实际显示顺序 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-step-review-evidence-v1.png](../../docs/design/browser-extension-recorder/workflow-step-review-evidence-v1.png) · 1 | superseded | 本轮未选用正文核对布局，未曾作为已批准目标 | 2026-10-30 | replacement: [方案2](../../docs/design/browser-extension-recorder/workflow-step-review-footer-v1.png) |
| [workflow-step-review-footer-v1.png](../../docs/design/browser-extension-recorder/workflow-step-review-footer-v1.png) · 2 | approved | 用户明确“确认2”：详情固定页脚勾选，应用后列表反馈；移除重复核对清单，总确认不再包含步骤 | 2026-10-30 | 替代editor-board-v1的核对交互及本轮候选1/3；replacement: none yet |
| [workflow-step-review-focus-v1.png](../../docs/design/browser-extension-recorder/workflow-step-review-focus-v1.png) · 3 | superseded | 本轮未选用核对优先的折叠编辑布局，未曾作为已批准目标 | 2026-10-30 | replacement: [方案2](../../docs/design/browser-extension-recorder/workflow-step-review-footer-v1.png) |

[交互提案](../../docs/design/browser-extension-recorder/step-review-design.md)记录核对持久化、变更失效、取消/应用和执行确认的边界；[完整提示词](../../docs/design/browser-extension-recorder/step-review-prompts.md)记录来源和实际显示顺序。三稿均不是运行截图；原始图不覆盖。用户已明确选定实际显示的第2稿，其为本次核对交互的唯一视觉目标；视觉批准与运行验证独立记录。2026-10-30已按方案2接入详情固定页脚核对、列表状态反馈、部分核对保存与内容变更失效；Chrome/Edge隔离回归和360×600/360×420布局检查通过。实现证据见 `build/validation-evidence/step-review/`，具体测试结果见验证矩阵与[实现复核](design-qa.md)；本轮没有新增或变更视觉稿状态。既有参数/成功条件和执行前确认要求继续适用。

### 步骤与参数编辑细化稿（核对交互已替代）

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-editor-board-v1.png](../../docs/design/browser-extension-recorder/workflow-editor-board-v1.png) | superseded | 旧分离核对清单、混合来源badge及总确认文案被替代；步骤/参数字段样式仍可参考 | 2026-10-30 | replacement: [workflow-step-review-footer-v1](../../docs/design/browser-extension-recorder/workflow-step-review-footer-v1.png)（核对交互范围） |

phase2 v3 的编译状态和列表布局继续有效；模型设置区域按下方模型列表修订登记执行，步骤/参数字段样式仍参考 editor-board-v1；其核对交互已由上方已批准的 workflow-step-review-footer-v1 替代。独立编辑事务与校验可按已有第二阶段实施授权推进；2026-10-29 用户明确确认本稿，开始接入这些编辑页面。来源、完整提示词与拟定交互见 [workflow-editor-prompts.md](../../docs/design/browser-extension-recorder/workflow-editor-prompts.md)。删除/重排入口不在本稿范围，本轮不接入；未应用修改的返回确认复用现有内联 Alert 样式。

### 模型列表选择与设置反馈（已批准并实施）

API Key 输入/更换态补齐既有视觉稿中的眼睛按钮：复用 InputGroup，默认 password，点击切换显示/隐藏，提供可访问名称和按下状态；鼠标切换保留输入焦点与光标，Enter/空格不提交表单。更换 endpoint 或离开设置页恢复隐藏；已保存状态仍只显示保存标记与更换/清除，不自动读取或回填已存明文。本次为现有输入框交互补齐，不改变视觉稿状态。

连接反馈与密钥保存方案已于 2026-10-29 获用户确认，随后明确要求顶部 Toast 并授权修改后实施；当前目标为 feedback-v3。旧 v2 的 Combobox、拉取、字段顺序和固定外框继续保留批准范围；测试跳转及“密钥仅本次使用”不再作为后续实施依据。

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [model-settings-connection-feedback-v3.png](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v3.png) | approved | 按用户“Toast 放顶部，其余确认”及“修改后开始实施”的定向授权实施；顶部悬浮、不挤动表单、保留已保存/更换/清除；不是声称用户逐像素审阅了生成结果 | 2026-10-29 | 替代 [feedback-v1](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v1.png) 的底部位置并纠正 v2 偏差；replacement: none yet |
| [model-settings-connection-feedback-v2.png](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v2.png) | superseded | 生成结果误将表单下移且改掉已保存密钥状态，未经批准，不得实施 | 2026-10-29 | 已由 [feedback-v3](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v3.png) 纠正替代 |
| [model-settings-connection-feedback-v1.png](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v1.png) | superseded | 底部 Toast 位置已被替代；配色、测试中按钮、原页等待与密钥保存交互按用户确认继承到 v3 | 2026-10-29 | [feedback-v3](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v3.png)；前序 [model-list-v2](../../docs/design/browser-extension-recorder/model-settings-model-list-v2.png) |
| [model-settings-model-list-v2.png](../../docs/design/browser-extension-recorder/model-settings-model-list-v2.png) | superseded | 连接反馈和密钥区域已由 feedback-v3 替代；Combobox、拉取及固定外框的原批准范围仍保留 | 2026-10-29 | 原替代 model-list-v1 和 phase2 v3 的设置区域；已由 [connection-feedback-v3](../../docs/design/browser-extension-recorder/model-settings-connection-feedback-v3.png) 替代 |
| [model-settings-model-list-v1.png](../../docs/design/browser-extension-recorder/model-settings-model-list-v1.png) | superseded | 首稿搜索态撑高外框并使用蓝色焦点，现由已批准 v2 替代；不得用于实施 | 2026-10-29 | 已由 [model-list-v2](../../docs/design/browser-extension-recorder/model-settings-model-list-v2.png) 替代 |

字段顺序为提供商、接口地址、API Key、模型。模型使用可搜索且可手动输入的 Combobox，同排 default 实心「拉取」按钮；仅显式点击拉取，加载时禁用重复触发，失败保留当前值并允许手动填写。更换地址后清除旧候选项，旧请求回包不得覆盖新地址结果；列表获取不等于连接测试通过。未触碰的空字段不立即报错，失焦或提交时校验。品牌、Tab、导航、footer 固定，正文仍为 ScrollArea，下拉在可用空间内定位并支持自身列表滚动。仅填写模型 ID 也可保存；无匹配项不阻止自定义值。完整提示词与来源见 [model-settings-model-list-prompts.md](../../docs/design/browser-extension-recorder/model-settings-model-list-prompts.md)。2026-10-29 用户批准 v2 后已接入模型列表功能；随后指出测试连接跳转及密钥无法复用，相关区域随后由已批准 feedback-v3 替代，已接入持久密钥和顶部 toast 流程。

### 第二阶段布局与局部修订

| 视觉稿 | 状态 | 适用范围 / 原因 | 状态日期 | 前序 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-phase2-board-v3.png](../../docs/design/browser-extension-recorder/workflow-phase2-board-v3.png) | superseded | 模型设置区域由 model-list-v2 替代；编译进度/失败与列表明确保留原批准范围，步骤/参数字段样式仍参考 editor-v1，其核对交互已由步骤就地核对方案2替代 | 2026-10-29 | 模型设置已由 [model-list-v2](../../docs/design/browser-extension-recorder/model-settings-model-list-v2.png)；前序 [v2](../../docs/design/browser-extension-recorder/workflow-phase2-board-v2.png)，步骤/参数已由 [editor-v1](../../docs/design/browser-extension-recorder/workflow-editor-board-v1.png) 细化替代 |

用户于 2026-10-28 授权开始第二阶段，包括独立底层开发；新页面仍遵循先审阅视觉稿再实现。以上稿件使用内置 imagegen 生成并已归档，完整提示词、流程约束与修订来源见 [workflow-phase2-prompts.md](../../docs/design/browser-extension-recorder/workflow-phase2-prompts.md)。2026-10-28 用户已明确批准 v3 的配色与布局，开始实现上述范围。model-settings-v1 的设置布局由 v3 替代，其他未覆盖的历史稿维持原状态。步骤与参数编辑以 [editor-board-v1](../../docs/design/browser-extension-recorder/workflow-editor-board-v1.png) 为当前目标；未展示的删除/重排控件仍待后续细化。

### 已批准的连接页优化

| 视觉稿 | 状态 | 生效范围 / 原因 | 状态日期 | 来源或替代稿 |
| --- | --- | --- | --- | --- |
| [connection-panel-v1.png](../../docs/design/browser-extension-recorder/connection-panel-v1.png) | 已批准 | 连接页固定底部元信息、复制成功态、工具链图标徽章、异常标题与时间同排 | 2026-10-28 | 用户提供的实现截图；无前序独立连接页稿 |

本稿已于 2026-10-28 获用户确认并实施，不改变其他已批准的录制/布局设计。当前连接页实现截图不是批准视觉目标；旧的随内容滚动 footer、安装实例纵向排列、工具链纯文字 badge 及异常时间另占一行不再作为开发依据。完整提示词见 [connection-panel-prompts.md](../../docs/design/browser-extension-recorder/connection-panel-prompts.md)。

### 已批准的固定外框与交互稿

| 视觉稿 | 状态 | 生效或失效范围 / 原因 | 状态日期 | 来源或替代稿 |
| --- | --- | --- | --- | --- |
| [recording-start-v3.png](../../docs/design/browser-extension-recorder/recording-start-v3.png) | superseded | 旧外层 padding 与内缩滚动边界已由 Box v2 替代；固定品牌/Tab、录制字段和记录行反馈保留批准范围 | 2026-10-29 | 当前外框 [Box v2](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v2.png)；[recording-start-v2.png](../../docs/design/browser-extension-recorder/recording-start-v2.png) |
| [recording-detail-v5.png](../../docs/design/browser-extension-recorder/recording-detail-v5.png) | superseded | 公共外框与内容间距已由 Box v2 替代；固定导航/底部操作和只读步骤行为保留批准范围 | 2026-10-29 | 当前外框 [Box v2](../../docs/design/browser-extension-recorder/popup-box-task-toolbar-v2.png)；[recording-detail-v3.png](../../docs/design/browser-extension-recorder/recording-detail-v3.png) |
| [recording-empty-v1.png](../../docs/design/browser-extension-recorder/recording-empty-v1.png) | 已批准 | 统一 Empty 搜索空态；导航和搜索在正文滚动区外 | 2026-10-27 | 暂无 |

### 仍有效的方向与主体设计

| 视觉稿 | 状态 | 生效或失效范围 / 原因 | 状态日期 | 来源或替代稿 |
| --- | --- | --- | --- | --- |
| [recording-popup-v1.png](../../docs/design/browser-extension-recorder/recording-popup-v1.png) | 已选方向 | 仅作黑白灰、功能 Tab 与录制状态的方向参考；不作为旧滚动/文案依据 | 2026-10-27 | 暂无 |
| [page-recording-toolbar-v1.png](../../docs/design/browser-extension-recorder/page-recording-toolbar-v1.png) | 已批准 | 网页展开浮条；本轮不改变网页浮条主体 | 2026-10-27 | 暂无 |
| [page-recording-toolbar-collapsed-v1.png](../../docs/design/browser-extension-recorder/page-recording-toolbar-collapsed-v1.png) | 已批准 | 网页收起浮条 | 2026-10-27 | 暂无 |
| [page-recording-toolbar-paused-v1.png](../../docs/design/browser-extension-recorder/page-recording-toolbar-paused-v1.png) | 已批准 | 网页暂停浮条 | 2026-10-27 | 暂无 |
| [recording-partial-v2.png](../../docs/design/browser-extension-recorder/recording-partial-v2.png) | 已批准 | 部分保存结果与必要缺口提示；外围布局遵循后续统一容器 | 2026-10-27 | 暂无 |

### 需修订（失效部分不得继续指导开发）

| 视觉稿 | 状态 | 生效或失效范围 / 原因 | 状态日期 | 来源或替代稿 |
| --- | --- | --- | --- | --- |
| [recording-list-v2.png](../../docs/design/browser-extension-recorder/recording-list-v2.png) | 需修订 | 需要采用统一 PopupPage/ScrollArea、记录行反馈和 Empty；20 条游标及全量搜索保留 | 2026-10-27 | 暂无 |
| [recording-saved-v1.png](../../docs/design/browser-extension-recorder/recording-saved-v1.png) | 需修订 | 常驻小字和模型提示块精简；先保存再整理保留 | 2026-10-27 | 暂无 |
| [recording-scope-v1.png](../../docs/design/browser-extension-recorder/recording-scope-v1.png) | 需修订 | 统一 NavigationBar/内容滚动；范围与加入确认保留 | 2026-10-27 | 暂无 |
| [model-settings-error-v1.png](../../docs/design/browser-extension-recorder/model-settings-error-v1.png) | 需修订 | 同设置页更新外围布局；错误与恢复信息保留 | 2026-10-27 | 暂无 |

### 历史稿（禁止作为当前目标）

| 视觉稿 | 状态 | 生效或失效范围 / 原因 | 状态日期 | 来源或替代稿 |
| --- | --- | --- | --- | --- |
| [workflow-phase2-board-v2.png](../../docs/design/browser-extension-recorder/workflow-phase2-board-v2.png) | superseded | 模型设置错误选中连接 Tab，已由 v3 替代 | 2026-10-28 | 前序 v1；替代稿 [v3](../../docs/design/browser-extension-recorder/workflow-phase2-board-v3.png) |
| [workflow-phase2-board-v1.png](../../docs/design/browser-extension-recorder/workflow-phase2-board-v1.png) | superseded | 下划线 Tab、拼图图标和彩色徽章已由 v3 修正 | 2026-10-28 | 替代稿 [v3](../../docs/design/browser-extension-recorder/workflow-phase2-board-v3.png) |
| [model-settings-v1.png](../../docs/design/browser-extension-recorder/model-settings-v1.png) | superseded | 设置布局采用已批准 v3；默认内存密钥策略不变 | 2026-10-28 | [v3](../../docs/design/browser-extension-recorder/workflow-phase2-board-v3.png) |
| [recording-partial-v1.png](../../docs/design/browser-extension-recorder/recording-partial-v1.png) | 已替代 | 中断原因与保存承诺不准确 | 2026-10-27 | [recording-partial-v2.png](../../docs/design/browser-extension-recorder/recording-partial-v2.png) |
| [recording-detail-v1.png](../../docs/design/browser-extension-recorder/recording-detail-v1.png) | 已替代 | 错误地将停止录制列为业务步骤 | 2026-10-27 | [recording-detail-v2.png](../../docs/design/browser-extension-recorder/recording-detail-v2.png) |
| [recording-start-v1.png](../../docs/design/browser-extension-recorder/recording-start-v1.png) | 已替代 | 旧入口图标与冗余文案 | 2026-10-27 | [recording-start-v2.png](../../docs/design/browser-extension-recorder/recording-start-v2.png) |
| [recording-detail-v2.png](../../docs/design/browser-extension-recorder/recording-detail-v2.png) | 已替代 | 旧返回栏与操作布局 | 2026-10-27 | [recording-detail-v3.png](../../docs/design/browser-extension-recorder/recording-detail-v3.png) |
| [recording-list-v1.png](../../docs/design/browser-extension-recorder/recording-list-v1.png) | 已替代 | 旧说明区与列表布局 | 2026-10-27 | [recording-list-v2.png](../../docs/design/browser-extension-recorder/recording-list-v2.png) |
| [recording-detail-v4.png](../../docs/design/browser-extension-recorder/recording-detail-v4.png) | 已替代 | 未批准初稿误给只读步骤增加可点击箭头；当前候选为 v5 | 2026-10-27 | [recording-detail-v5.png](../../docs/design/browser-extension-recorder/recording-detail-v5.png) |
| [recording-start-v2.png](../../docs/design/browser-extension-recorder/recording-start-v2.png) | 已替代 | 整页滚动、选项双层文案与缺少列表反馈已替代；开始操作与首页 5 条保留 | 2026-10-27 | [recording-start-v3.png](../../docs/design/browser-extension-recorder/recording-start-v3.png) |
| [recording-detail-v3.png](../../docs/design/browser-extension-recorder/recording-detail-v3.png) | 已替代 | 品牌/Tab/返回栏随正文滚动的边界失效；default 保存与 destructive 删除保留 | 2026-10-27 | [recording-detail-v5.png](../../docs/design/browser-extension-recorder/recording-detail-v5.png) |

新增稿完整提示词见 [popup-wrapper-prompts.md](../../docs/design/browser-extension-recorder/popup-wrapper-prompts.md)。新候选未批准前，原已批准稿按失效范围标为需修订，不自动标为已替代；新稿明确获批后再更新对应旧稿。原图与历史审批均保留。

## 附录 B：审阅记录（原始证据，按时间倒序）

- 2026-10-28：视觉稿状态登记与设计规范集中到本文件（DESIGN.md），`docs/design/browser-extension-recorder/README.md` 改为仅保留链接；根 AGENTS.md 同步修订登记位置。不改变任何稿件的既有状态。

- 2026-10-28：用户确认连接页 v1，已实现固定 footer、完整实例号复制及短暂 success 对勾、工具链图标徽章和异常标题/时间同排。未改变连接协议；本次没有前序独立连接页稿需要标为已替代。

- 2026-10-28：按用户明确要求精简开关文案为「同时录制从当前页面打开的新标签页」。首页 v3 图中的旧句仅作为历史图像保留，不再指导该标签实现；其余已批准布局保持有效。

- 2026-10-27：用户确认首页 v3、详情 v5 与空态 v1，批准固定外框、正文 ScrollArea、Empty、列表 hover/focus 反馈和单条选项文案。首页 v2 与详情 v3 标为已替代；全部列表沿用已确认的分页逻辑并应用同一容器/交互规则。

- 2026-10-27：用户单独允许删除共享 ScrollArea 第一行未使用的 React 导入，以解决此次引入该组件后的类型检查错误；仅限这一行，不改变组件 API、样式或行为，不构成后续直接修改共享组件的通用授权。

- 2026-10-27：用户指出外层滚动、开关文案、列表反馈和空态问题，要求统一 ScrollArea、Empty，并讨论通用容器与 Jotai。当时先生成首页 v3、详情 v5、空态 v1 并标记旧稿失效部分；随后用户确认并获准实施，见最新记录。详情 v4 的错误箭头已纠正并留档。

- 2026-10-27：用户确认全部记录页 v2，状态更新为已批准，列表 v1 标为已替代。随后实施首页 5 条、全部列表 20 条游标分页、全量搜索、返回位置保留和详情 50 条事件分页。

- 2026-10-27：用户确认分页方案：首页最近 5 条、全部列表每批 20 条游标加载更多、详情每批 50 条事件；先生成全部记录页视觉稿再实现。本次新增列表 v2 待审阅，不把方案确认等同于新图审批。

- 2026-10-27：用户同意入口 v2 与详情 v3，并明确修订：连接 Tab 必须第一且默认展示；保存等实际提交操作使用 shadcn default 实心按钮。两稿在上述修订范围内获批，原图对应的旧 Tab 顺序和 outline 保存按钮不作为实施依据；不覆盖原图。入口 v1 与详情 v2 更新为已替代。

- 2026-10-27：用户反馈插件需要独立顶层容器、统一 NavigationBar、重设计录制图标、删除冗余提示，并要求删除按钮使用 destructive。相关旧稿按上表标为需修订，已生成入口 v2 与详情 v3 待审阅；本轮不先改前端代码。

- 2026-10-27：用户明确授权第一阶段实施，并要求先建立 recorder 分支。该授权仍有效；当前较大前端变化按用户新增要求先出稿确认，不能把本轮待审阅稿当作获批目标。

- 2026-10-27：用户回复「批准」，确认录制开始 v1、暂停工具栏 v1、部分保存 v2、录制列表 v1、录制详情 v2 五张当前稿；不含两个已替代 v1，不授权代码实施。

- 2026-10-27：用户明确确认展开工具栏、模型设置和参与页面管理三张视觉稿，状态更新为已批准；接续补齐录制流程。视觉批准不授权实施或更改密钥持久化方案。

- 2026-10-27：用户对本轮三张补充稿回复「同意」，批准收起工具栏、录制保存结果和模型连接失败视觉稿。其余稿件保留原审阅状态；本次不扩大为实施授权，也不决定密钥持久化方案。

## 附录 C：交互边界、状态稿说明与待定事项

### 交互边界与待定事项

- 延续现有插件黑白灰、黑色主按钮、浅灰分区、圆角边框与细线图标。红色只提示录制/异常状态。生成图的细微样式漂移不构成新主题决定。
- Popup 是管理入口，网页工具栏是录制期间的主要控制。已参与页面共享一次录制的状态；无关页面不自动采集。收起不等于暂停或停止。
- 模型配置属于插件。早期稿采用任务内存密钥方案；2026-10-29 用户已明确批准保存配置时持久保存当前接口密钥，当前以 feedback-v3 与融合设计的 endpoint 绑定、受信存储及明确清除契约为准。
- 收起工具栏、保存结果及模型失败三张状态稿于 2026-10-27 获用户批准；原批准仅针对当时视觉版本；当前生效范围以上表为准。
- 浏览器图标状态以角标方案评审；页面参考背景和生成的浏览器外壳均为示意，不是 Chrome/Edge 的真实验收截图。

### 状态稿的交互说明

- 工具栏收起仅改变展示密度，不暂停采集。图标按钮须有可访问名称和 Tooltip；停止是保存操作，不设为丢弃。浮条应限制在可视区域内，拖动时不触发页面业务操作。
- 保存结果只在录制数据收尾后显示。示例是完整保存状态；若存在尾批次缺口，必须改为明确的部分保存提示，不能沿用成功图标掩盖缺失。默认名称可以修改，关闭 Popup 不丢已保存记录。
- 模型连接失败稿展示服务端明确拒绝凭据的场景；超时、网络不可达和模型不存在要使用各自准确文案，不能一律归因密钥。保存配置与测试通过是独立状态，保存不触发整理/重放；错误详情必须脱敏。
- 图像生成未验证 360px 真实排版、键盘焦点、响应式和 Tooltip。设置页内容超出 Popup 可用高度时，表单内部滚动、操作区保持可达；具体尺寸以之后获准的交互原型验证为准。
- 首次开始必须确认起始页和允许站点；包含关联新页默认关闭。只允许页面范围内的录制，不能将浏览器安装权限当作全局录制同意。
- 暂停冻结有效录制时长，所有参与页暂停采集；已提交步骤仍保留。继续时复核页面身份，暂停期间发生导航等变化须标明上下文变化，不把期间操作补录为事实。
- 部分保存示例是浏览器整体意外退出后重新打开 Popup 的状态；单个 Tab 关闭并不必然中断整次录制。已存事件可查看，未知尾部显示缺口，不给出自动恢复或无损保存承诺。
- 列表中的「已整理」仅表示有对应工作流草稿或结果，不能等同于已审阅可运行。录制行点击进入详情，不直接执行；记录与工作流分属不同导航入口。
- 详情的时间线保持全局顺序，按连续页面片段分组；同一页面再次出现不能把前后步骤重新聚合打乱顺序。暂停、停止和浮条点击是会话控制元数据，不计为可重放业务动作。

### 尚待补齐的完整产品流程

本轮补齐录制主流程，不代表所有功能视觉稿已完成。后续仍需工作流列表、编译/失败与参数审阅，重放参数输入、执行进度、人工确认、成功/失败结果，以及录制设置、数据设置和连接管理整合稿。第一阶段已获实施授权并在 recorder 分支推进；较大前端修订须先确认新稿，其余后续阶段仍待设计与授权。

### 已确认的容器与导航方案

- `main.tsx` 挂载独立 `ExtensionPopup`，顶层仅负责品牌栏、Tab 容器与各功能入口；连接 Tab 排第一且每次打开默认选中，顺序为连接 / 录制 / 工作流；录制功能不作为其他功能的外层容器。不为尚未存在的功能创建动态注册框架。
- 录制、连接各自管理业务状态和订阅；公共 `NavigationBar` 属于插件界面层，统一返回按钮、标题、右侧状态/操作及间距，不移入共享 Agent 或修改共享 shadcn 源码。
- `NavigationBar` 提议采用左侧固定尺寸返回图标、中间标题、右侧状态/操作，返回目标用 `aria-label` 与原生 `title` 表达；顶级页面可不传返回操作。
- 录制按钮使用图标库 `MousePointerClick`，表达网页操作录制；不使用空心圆或视频录制图标。
- 保存等明确提交数据的操作使用 default 实心 Button；取消、返回等次要操作保留 outline/ghost。
- 删除操作直接使用 `<Button variant="destructive">`，保留删除确认；去除常驻的“无需连接”“本地保存”“功能尚未开放”等重复提示。权限范围、敏感信息隐藏、缺口和失败恢复提示仍按需保留。
- 入口 v2 仅展示当前起始站点摘要；若尚无站点管理用例，实施时不渲染无效的可点击箭头。新功能的视觉细节应在获批且真实可执行后展示。

完整提示词见 [popup-refinement-prompts.md](../../docs/design/browser-extension-recorder/popup-refinement-prompts.md)。

### 已实现的记录分页（行为已确认，外围布局已在正文 Components 记录）

当前实现：首页只读取最近 5 条终态记录；全部列表以创建时间和 ID 的稳定游标每批读取 20 条；详情按事件序号每批读取 50 条。IndexedDB 以增量索引升级保留原有录制，不再使用最近 100 条截断作为完整列表。

分页交互补充约束：

- 全部列表采用固定可用高度的内容滚动区；NavigationBar、搜索和底部加载操作保持可达。每批 20 条不等于总数上限，不一次展示全部数据。
- 「已加载 N 条」反映实际已加载的匹配记录，不冒充总数。加载期间按钮进入忙碌态；失败保留列表并提供原位置重试；没有后续数据时结束加载入口。
- 搜索关键词变化时重置游标并查询完整存储范围；过期查询结果不能覆盖新关键词结果。进入详情再返回应恢复已加载记录、查询与滚动位置。
- 首页最近列表不与全部列表共享截断上限；用户打开 Popup 仍首先看到连接 Tab，录制分页不会改变插件的主要入口。

### 固定外框与内容滚动方案（已批准并实施）

- `ExtensionPopup` 保持独立，管理品牌栏、Tab 和整体可用高度；连接 Tab 第一且默认显示。根节点/页面 body 不产生外层滚动。
- 抽取应用级 `PopupPage`，提供可选导航、工具区、正文和底部操作区。NavigationBar、搜索等必要工具和底部操作在 ScrollArea 之外；正文用共享 ScrollArea，采用 `flex-1`、`min-h-0` 与确定的高度链；外壳无 padding，品牌/Tab/导航/footer 各用 Box，正文 Box 在全宽 ScrollArea 内，不再使用外层 p-4 与内层 pr-3。避免每页再设置孤立的固定高度或叠加原生滚动条。
- 连接页、录制首页、记录详情与全部列表采用同一布局契约；首页仅正文滚动，子页 NavigationBar 不随内容移动。滚动恢复绑定 ScrollArea 的实际 viewport，不继续依赖旧 overflow div。
- 可点击记录行统一使用语义 button/链接、整行 hover/active 背景、pointer 光标、尾部 chevron 与 focus-visible 焦点反馈；键盘 Enter/Space 可进入详情。只读事件行不添加箭头或点击样式。
- 空数据统一组合 Empty / EmptyHeader / EmptyMedia / EmptyTitle / EmptyContent。首次空列表显示「暂无录制记录」；搜索无结果显示「未找到匹配的录制」并可清空搜索。加载用 Skeleton，失败用错误/重试提示，不伪装成 Empty。无溢出时不显示滚动条，无更多数据时不保留加载按钮。
- 开关当前文案为「同时录制从当前页面打开的新标签页」。勾选后，将参与页面打开的新标签页纳入录制，仍须满足同一窗口与本次允许站点的规则；不自动录制其他已打开的标签页。技术范围不再堆进主标签。
- 暂不引入 Jotai：本轮是布局与交互职责调整，现有 Popup 内的导航/查询/滚动状态可由所属组件管理。如果将来出现跨多个功能页的明确状态共享，再评估 Popup 范围的 Provider/atom；不会将录制权威状态从 Worker/IndexedDB 迁移到 React 状态库。
- 验证重点：滚动长首页/详情/列表时 header、Tab、NavigationBar 的位置不变；body 无滚动；仅一个内容 viewport 滚动；浅深色、短屏高度、键盘焦点、空态及返回滚动位置均需实际浏览器检查。

固定外框与三个批准状态已落地到 recorder 分支；实际验证与证据统一见 [验证矩阵](../../docs/poc/executor-validation.md)。截图为独立测试 Profile 的实现证据，不替换生成视觉稿。共享 ScrollArea 的唯一源码改动是用户明确授权删除一个未使用导入。

### 连接页 footer 与诊断区设计（已批准并实施）

- 复用 PopupPage 的 footer 插槽：版本、安装实例均为 label/value 左右结构，footer 不在正文 ScrollArea 内；内容不足时仍位于底部，长内容只滚动正文。品牌栏和 Tab 保持固定。
- 实例号单行截断，完整值通过 Tooltip 展示；末尾 ghost icon button 点击复制完整原始 ID。写入剪贴板成功后才切换 success 色 CheckIcon，约 1.5 秒恢复 CopyIcon；重复点击重置反馈期限，卸载清理计时器。失败不显示成功对勾，使用简短可访问反馈；无实例号时不提供可用复制按钮。
- 工具链 badge 与连接 badge 保持相同高度、间距与 icon + text 结构：就绪用 CircleCheck，未就绪用 CircleMinus；不能把未就绪暗示为已连接或新错误。
- 异常标题和时间使用同一 flex 行 justify-between；时间显示短格式，Tooltip 提供完整时间；错误码/方法/原因可换行。正文超过剩余高度时由 PopupPage 的单个 ScrollArea 滚动，避免默认嵌套两套滚动条，元信息 footer 始终固定。
- 重连与暂停保留当前行为与按钮层级。静态图展示的是复制成功瞬间，不能把绿色对勾当常驻复制图标；没有改变连接协议、诊断字段或权限。

## 附录 D：来源与保存约定

原始生成文件保留在 `C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/`。[docs/design/browser-extension-recorder/](../../docs/design/browser-extension-recorder/) 目录内的图像副本是项目内的稳定审阅入口，不依赖该机器路径。用户提供的现有 Popup 截图是风格参考，未作为运行验收证据；未选的第一、第二版暂不纳入选定方向目录。

生成方式：内置 Image Gen。提示词记录见 [prompts.md](../../docs/design/browser-extension-recorder/prompts.md)、[recording-flow-prompts.md](../../docs/design/browser-extension-recorder/recording-flow-prompts.md)、[popup-wrapper-prompts.md](../../docs/design/browser-extension-recorder/popup-wrapper-prompts.md)、[popup-refinement-prompts.md](../../docs/design/browser-extension-recorder/popup-refinement-prompts.md)、[connection-panel-prompts.md](../../docs/design/browser-extension-recorder/connection-panel-prompts.md)、[recording-pagination-prompts.md](../../docs/design/browser-extension-recorder/recording-pagination-prompts.md)。新迭代使用递增版本文件名；旧稿不覆盖，状态变更在本文件附录 A 登记。

### 2026-10-29 表单实现约定

用户指定使用 shadcn 的 TanStack Form 方案。工作流模型设置、审阅、步骤与参数编辑使用 @tanstack/react-form，Field 负责可访问标签和错误呈现；导航/展开/放弃确认仍为局部 UI 状态。此技术选择不改变已批准视觉范围。子页应用不写入存储，主页面保存后增加版本并重新审阅；顶部 Tab 切换保留本次 Popup 内的编辑状态，关闭 Popup 后仅已保存数据可恢复。

### 成功条件字段反馈（2026-10-30 局部优化）

沿用已批准的工作流审阅页及 TanStack Field/FieldError/FieldDescription，在原成功条件输入框下显示针对性错误或核对说明。非法地址或不明确元素目标用现有错误样式；未观察地址和有限检查使用现有辅助说明样式。发布门禁与Worker一致，修改清除旧审批。没有新增页面、对话框或布局方向，不变更既有视觉稿批准范围。

2026-10-31实施记录：用户在视觉稿确认后明确“开始实施”，现已接入引导提问、回答恢复、暂缓草稿回访与整理预览。两张v2仍保持approved；实现验证与截图另见design-qa.md和验证矩阵，不能把生成图当运行证据。本次未修改原图。

2026-10-31用户明确局部修订：录制详情底部的“查看工作流 / 重新整理 / 删除录制”同一行等宽排列，替代此前“查看工作流”独占一行的布局。固定footer及删除确认规则不变，查看用outline、整理用default、删除用destructive；没有工作流时自然显示两项操作。该明确布局要求直接作为本区域批准依据，旧稿两行按钮区域不再指导实现；其它区域状态不变，无需新增整页视觉稿。

2026-10-31用户明确局部修订：插件内列表行及导航/页脚的分隔线统一使用独立Separator，替代divide-*或用于分隔的单边border。分隔线不附着在带圆角的可点击行上；外层卡片、输入框完整边框不变。此要求替代旧稿中可能被误读为圆角行边框的分割表现，其余已批准布局保持不变。

2026-10-31用户明确局部修订：所有列表item间距统一为0，Separator紧贴相邻条目，不继承页面区块的gap。全部录制列表新增独立列表容器；最近录制、工作流、历史、步骤/参数及证据列表采用同一零外间距原则。保留item内部padding、图文间距及日期分组层级；本规则覆盖旧稿的行间空隙，其余批准范围不变。


### 最近工作流与全部工作流（2026-10-31，已批准接入）

| 视觉稿 | 状态 | 适用范围 | 状态日期 | 原因 / 替代关系 |
| --- | --- | --- | --- | --- |
| [workflow-recent-all-compact-v1.png](../../docs/design/browser-extension-recorder/workflow-recent-all-compact-v1.png) | approved | 最近10条首页、仅全部页搜索/分页、列表48px最小行高与8px内边距、列表外层py-2、Separator my-2，查看全部最右（后续用户局部修订） | 2026-10-31 | 用户明确回复“确认，按此稿接入”；替代原首页展示所有工作流及首页搜索、原64/80px行高；replacement: none yet |

[来源与交互契约](../../docs/design/browser-extension-recorder/workflow-recent-all-prompts.md)。录制与工作流使用同一PopupListItem几何；卡片、表单和业务详情的区块padding仍保留。旧phase2首页列表范围已由此稿替代，编译/编辑/问答交互范围不变。原历史状态稿仅列表密度与首尾留白由本次用户要求覆盖，状态/重试行为继续有效。原图不覆盖。

2026-10-31用户最新局部调整：列表外层改为py-2，列表Separator改为my-2，item继续使用统一p-2/min-h-12；此决定覆盖此前“外层py-0/Separator无margin”的间距要求，列表容器gap-0仍保留以避免叠加。最近工作流标题栏从左到右为整理历史、模型设置、查看全部，查看全部位于最右侧。该明确调整作为recent-all-compact-v1的已批准局部修订，其它布局/分页/搜索规则不变。

2026-10-31用户明确状态配色调整：录制“已整理”和工作流列表“已发布”采用success语义绿（text-success、bg-success/10、border-success/20），适配明暗主题；待整理、整理中、草稿等继续原中性色。记录/工作流列表样式复用同一对应Badge实现，不修改共享shadcn Badge源码或把发布当作业务执行成功。此项覆盖旧视觉稿中这两种状态的中性色表现，其余状态范围不变。

2026-10-31目标修订：用户确认删除完成判断页的“相关录制”块，并明确目标为智能体自主将录制整理成可重放Skill，用户在本地Skills文件夹维护。当前固定完成判断题与复杂工作流维护交互不再作为后续目标，相关两张v2已标记revision required；尚无替代视觉稿。此次仅落实已确认的局部删除，新Skill交互继续讨论，不把新方向写成已经实现。原始录制与后台来源校验仍保留。

2026-10-31流程要求：用户进一步明确先定完整Skill Agent闭环方案，再出界面，最后实施。方案见[Skill Agent](../../docs/architecture/browser-recording-skill-agent.md)；此时不生成替代视觉稿，现有revision required范围不自动恢复为approved。

## 2026-11-01 实施授权

用户确认最新三组状态细化并明确要求实施完整计划。已选详情方向及详情状态v1、整理会话v2、历史/重放v2均为approved；对应颜色错误v1为superseded。未展示的多选/保存失败/未知结果/短窗仍需补充视觉审阅，后台可独立推进。技能固定库及重新生成成功后绑定新副本按确认计划执行。

### 会话时间线样式修正（2026-11-01）

用户明确要求使用 ScrollArea 统一滚动条，并参考 Claude Code 添加节点连接线。本次修正既有会话正文的滚动/连线及当前问题归属，沿用已确认的外框、颜色和操作布局，不新增页面或业务步骤。ScrollArea 与 MessageScroller 共用同一视口，品牌/Tab/导航/footer 固定；图标顶部对齐、相邻节点间细线连续、最后节点后不延伸，当前问卷位于对应提问节点而非独立空头像行。

以下旧稿的会话正文滚动/无连接线区域标为 revision required，replacement: none yet；其品牌、Tab、导航、表单控件、状态配色和footer继续作为有效参考：skill-organizer-session-states-v2.png、skill-replay-history-states-v2.png、skill-agent-additional-states-v2.png。本次实施依据为用户直接指定的样式修正；运行截图是实现验证材料，不替代视觉稿或自动取得新的视觉批准。

### 已弃用：展开节点与可读卡片候选（2026-11-01）

| 文件（已删除） | 状态 | 范围 | 状态日期 | 原因 / replacement |
| --- | --- | --- | --- | --- |
| `skill-timeline-cards-v1.png` | deprecated | 整理技能时间线卡片收起/展开候选 | 2026-11-01 | 用户明确否决并要求删除；关联方案 `skill-timeline-cards-design.md` 同时删除；replacement: none yet |

此候选未获批准、未实施，不得继续作为设计或开发依据。按用户明确删除要求移除仓库图稿与关联文档，仅保留弃用记录。之前标记revision required的会话稿不因此恢复approved；已实施的独立局部调整保持现状。

### 录制详情整理入口（用户定向修订）

未完成的已有整理任务显示“继续整理”（StepForward）；已完成显示“查看整理”（FileText）；从未整理显示“开始整理”（Sparkles）。进入已有任务按显式会话ID读取，不创建新任务、不自动调用模型。进行中/待答/待保存任务优先，其余取最新整理会话；旧中断记录不能覆盖更新的完成记录。重新生成入口保留在已完成会话底栏，明确点击“重新整理”才开始新任务。此为用户直接指定的文案/图标和入口语义修订，沿用当前布局，无需新视觉稿；时间线卡片候选随后被用户否决并删除。

### 节点密度与日期字段（用户直接修订）

时间线节点由32px缩小至20px，内部图标12px，连接线居中同步调整。日期字段使用shadcn Date Picker标准组合（Button、Popover、Calendar），中文日历，选择后关闭并恢复触发器焦点，可清除，显示与提交YYYY-MM-DD；不通过UTC转换改变日期。普通文本/邮箱/数字以及单选/多选继续复用现有shadcn Questionnaire/Field组件，缺少合适组件时才做应用级组合。Popover经Portal呈现，窄窗不得被正文裁切。此为用户指定的局部控件修订；本条独立生效，已否决的卡片候选不再作为参考。

2026-11-01 用户定向修订：会话导航栏“停止任务”采用红色实心按钮及填充方块停止图标，保留原位置、可访问名称和忙碌禁用状态；通过应用层Button样式组合实现，不修改共享destructive变体或停止语义。

2026-11-01 用户明确密度修订：当前问答的正文/字段标题统一14px；文本/邮箱/数字输入及Date Picker触发器统一默认32px高度，选择项最小32px且长文案可自然增高，字段组间距16px。不沿用Questionnaire的小屏16px/44px触控默认；通过应用级className调整，保留共享组件及表单行为。

2026-11-01 用户确认状态文案统一：failed在整理历史与会话详情统一显示“失败”，使用同一异常图标与destructive语义色，具体原因仍由错误Alert说明。两处共用session-status映射，等待/保存/停止/中断等状态也使用同一命名；重放completed仍显示“已结束”，不改为业务成功。

### 浏览器优先保存与离线重放（2026-11-02）

用户同意离线闭环并授权设计后实施。保持现有双Tab、固定外框、详情状态行和页脚布局，文件区通过现有Button/DropdownMenu提供导出副本、保存到本地目录、打开本地目录。浏览器保存成功显示“已保存到浏览器”，关联Native回执后显示“已关联本地目录”；未连接不再阻止默认整理与重放。离线时主文件操作为导出，连接且有磁盘关联时为查看SKILLS。

缓存重放复用现有Dialog：副本时间、可能未包含后续手改的说明、取消/使用副本继续。未确认不创建运行；确认绑定所选副本摘要。会话内仅缓存降级时显示来源提醒，不用常驻小字堆叠正常流程。已弃用的卡片重设计不恢复。

旧状态稿中“Executor离线则整理尚未完成/重放禁用”的保存依赖区域为revision required，现有同状态登记保持不变；其配色、固定布局和控件仍可参考。本次为用户指定离线语义在既有控件槽位的接入，详细状态及故障边界见[离线方案](../../docs/architecture/browser-skill-offline.md)。

2026-11-02 用户定向文案修订：录制列表已关联技能状态由“已生成技能”缩短为“已整理”，保持绿色语义样式和原状态判定，与“待整理/整理中”对应；不表示重放成功或已同步到Executor目录。

2026-11-02 用户指定连接Tab增加6px状态圆点：基于ConnectionPanel现有实时Worker状态（不新增轮询、不信任旧storage标签），connected绿色，disconnected/incompatible红色，connecting/paused/未取得状态灰色。圆点附可访问名称，Tab保留“连接状态”名称与原生title状态说明；切换到录制页仍更新。此为指定局部视觉修订。

### 2026-11-02 执行限制设置

用户授权在全局设置增加可触达的执行限制，并提高默认轮数。沿用现有设置表单、Field/Input 和独立保存按钮，整理默认 50、重放默认 100，范围 1–500。预算耗尽详情展示已用/上限、设置入口及“追加轮数并继续”；确认后增加最多 20 轮，总上限 500。不采用已弃用的时间线卡片视觉稿。此项为已授权的功能调整，不新增视觉稿状态。

### 会话工具详情局部修订（2026-11-02）

2026-11-03用户明确要求限制展开会话卡片高度并使用ScrollArea（approved）：工具参数和返回数据的JSON卡片，内容视口最高20rem（默认字号下320px），且不超过40dvh；短内容自然高度。复用共享ScrollArea及既有Card，保留JSON换行与配色，右侧为主题滚动条；溢出时视口可键盘聚焦，PageDown和滚轮可滚动，边界允许衔接外层会话。此为用户指定的局部滚动例外，会话主容器仍只有一个统一视口；问题表单和错误操作区不因此裁切。不归档含用户真实邮箱数据的原截图，使用合成数据做运行验证；无新增视觉稿，replacement: none yet。

用户明确指定：JSON数据使用现有shadcn Card包裹；折叠操作保留原生details/summary键盘语义，以Lucide ChevronRight图标表示展开状态，隐藏浏览器三角标记；20px时间线圆点与20px标题首行垂直居中对齐，展开内容不影响圆点位置。保留单个ScrollArea滚动视口，不复用此前已弃用的整体卡片候选稿。本次仅为当前界面的局部修订。

### Popup与智能体侧边栏分工（2026-11-02）

用户确认实施：保留Popup及当前页面设计，整理/重放会话与运行宿主移入窗口级全局sidePanel。Popup保留连接、录制管理、设置和整理历史列表；历史条目按明确任务ID打开侧边栏。面板沿用品牌栏、导航、时间线、JSON卡片、提问表单和页脚，自适应可变宽高；不复制连接/录制Tab。返回操作显示“返回会话入口”，入口空态提示从扩展弹窗选择任务。设置往返保留会话与表单。关闭面板保留会话，重新打开显式继续。此为用户指定的宿主迁移和布局适配，不恢复已弃用视觉稿。

### 会话历史统一归属window-panel（2026-11-02，用户确认实施）

本次直接确认替代上节“历史列表留在Popup”的导航规则。保留现有黑白灰、PopupPage/ScrollArea、Separator和列表行设计：window-panel首页为会话历史，以全部/整理/重放Tabs筛选；条目展示类型、录制名称、状态和最近活动时间。列表与详情两级导航，标题栏历史图标可随时回列表，不增加第二列常驻侧栏。列表保留筛选、已加载条数和滚动位置；没有数据、加载失败和重试各自明确显示。查看其他会话不卸载模型宿主，提供返回当前运行/待回答/待核实会话入口。

Popup录制详情移除历史图标；已有整理时统一“查看整理”（FileText），打开最新创建的整理会话，不因旧会话仍未完成而覆盖最新记录；从未整理时“开始整理”。“重放”新建任务，已有活跃重放时显示“查看重放”并解释不会新建。连接状态、设置、删除与技能文件操作不变。此项复用当前列表和详情视觉，不恢复已弃用候选稿；实现截图归验证证据。

### 执行中时间线文案（2026-11-02）

按用户指定使用已安装shadcn Marker/MarkerContent和shimmer工具类。最新工具调用处于pending/dispatched且任务正在运行或保存时，仅其标题动画；等待模型响应时末尾独立进度节点显示“正在整理…”或“正在规划下一步…”，不将已返回的历史结果标成执行中。待回答、失败、完成、中断、停止和保存错误保持静态。使用motion-safe:shimmer，减少动态效果时保持可读静态文字，圆点尺寸/连接线/标题对齐不变。

### 页面等待设置（2026-11-03）

2026-11-03等待重试文案（approved，用户选择单行提示）：运行技能时在当前打开/导航工具节点内显示实际等待进度。第一窗口「等待页面就绪… 1/3」，后续「页面尚未就绪，重试中… 2/3」；分母使用任务保存的配置，不固定为3。保留工具名称及可折叠参数，状态在折叠时也可见；中性色、现有Marker动效、role=status与reduced-motion，不新增警告卡片或模型消息。只在正在执行的当前工具显示，结束/停止/失败后隐藏运行提示。次数来自Worker账本，不用前端计时模拟；正常窄窗单行，200%放大允许自然换行以保证完整可读。沿用既有时间线，无新增视觉稿，replacement: none yet。

2026-11-03页面等待设置局部规格（approved，用户直接确认默认15秒、连续3次超时后报错且window-panel可配）：沿用模型设置页Input/Field/TanStack Form，在执行限制后新增「页面等待」分组，两个整数字段分别为1–60秒、1–5次，仍只有底部统一「保存配置」。默认值15/3，说明只影响新任务、等待不重复打开或额外调用模型；复用当前设置视觉，无新增图稿，replacement: none yet。

### 会话删除（2026-11-02）

用户指定整理/重放详情状态Badge之后紧邻删除图标按钮，使用Button size="icon-xs" variant="destructive"，title和aria-label为删除会话。复用Dialog确认，取消在左、确认删除在右。默认删除仅移除该会话和问答；提交绑定原revision/epoch，确认期间变化必须重试。正在执行/保存和未决页面副作用不允许删除，禁用按钮title说明原因；静止待回答会话可删除。删除成功返回会话历史并清理保存的详情导航。

2026-11-03 用户明确确认的局部交互修订（approved）：整理会话有生成产物时，确认框增加默认未选中的单个 Checkbox「同时删除本次生成的技能」，统一清理该生成 ID 的浏览器副本和已保存本地文件，不提供分开保留一方的选项。保留录制，不影响后续生成。说明本地手改内容也会删除及连接要求；失败在框内提示并保留选项和会话。重放不提供此选项。沿用当前 Dialog 布局，无新增图稿；替代此前无条件保留技能的说明，其余区域不变，replacement: none yet。

### 自行说明与单一设置入口（2026-11-02，用户确认实施）

按用户参考Questionnaire交互增加系统级答案出口：选择题额外显示“其他，自行说明”，选择后在原QuestionnaireItem内展开QuestionnaireInput；其他类型字段通过“不适用／自行说明”切换到同一输入控件。保留正常尺寸和原问答布局，不使用独立Textarea或自由会话输入框。输入说明需非空；切回普通模式后按原字段规则校验。当前问题及历史工具答案延续原时间线，不自动把说明当成参数字面值。

Popup移除设置齿轮和设置路由；设置页面归features/model-settings，唯一入口位于window-panel品牌栏。跨窗口冲突用现有warning Alert，提供“加载最新配置/限制”和“保留当前编辑/限制”，保存按钮在冲突未处理时禁用。干净表单自动同步，草稿保留；不显示存储密钥明文。

### 设置单一保存入口（2026-11-02，用户明确修订）

移除“保存执行限制”按钮及独立表单，执行限制直接加入ModelSettings的TanStack Form。底部“保存配置”统一提交模型、密钥更换、发送授权、整理与重放轮数；保留测试连接操作且不写配置。此前独立保存/独立冲突提示规则被本条替代，冲突统一提供“加载最新配置 / 保留当前编辑”。不改变已有字段布局和本次任务预算快照。

### 会话错误复制诊断（2026-11-02）

按用户要求，会话错误、工具错误和校验错误Alert的action区域增加“复制诊断”按钮（Copy图标、outline、xs），默认可见，不需要先展开详情。复制内容含sessionId、recordingId、模式、状态、epoch/revision、时间、模型调用数及错误码/安全说明；工具错误附toolCallId和消息位置，校验错误只附有限代码和白名单字段路径。不复制接口地址、密钥、录制名称、模型原文、用户输入或工具原始数据。完成剪贴板写入后才显示已复制，拒绝访问时显示可重试失败提示；切换诊断清除旧反馈。

### 无工具响应恢复（2026-11-02）

保留模型纯文本回复在原时间线中，运行中状态及Marker延续现有样式，只有submit_skill保存回执或finish_run结果才进入相应终态。错误文案区分空输出、截断、过滤、未知结束原因和纠正上限；复制诊断增加lastResponse和累计纠正次数，不含原文。旧SKILL_NO_TOOL失败详情沿用页脚双按钮布局，提供“继续整理”/“核对并继续”，不自动执行，也不跳过已有未知副作用核实。

### 提问参数错误已纠正（2026-11-02，错误修复）

沿用原时间线、ToolDetails和Alert组合，不改页面布局。对于ask_user_question的SKILL_TOOL_INPUT_INVALID，只有后续问题已被Worker正式接纳为当前待答，或已有真实answered回执，旧节点才显示“询问用户 · 参数已纠正”；默认折叠，展开为info Alert并保留原错误诊断和复制操作。新的失败尝试、未知结果、不同工具成功、问题次数上限均不能作为已纠正依据；其他未恢复错误仍保持danger Alert。

诊断和错误详情优先读取相同toolCallId/toolName的持久工具账本，避免将SDK校验长文本误显示为UNCLASSIFIED_ERROR或泄漏字段值。复制信息可含recovered标记、安全校验代码和白名单字段路径，不含原始SDK错误正文。未保存字段级诊断的旧记录不猜测补齐，仍可显示已有稳定错误码。
