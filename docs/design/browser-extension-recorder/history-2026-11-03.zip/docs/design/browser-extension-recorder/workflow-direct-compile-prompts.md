# 一键整理、首次授权与失败恢复

日期：2026-10-29。用户明确确认正常链路直接整理、设置仅作为配置或故障修复入口，并授权开始实施。视觉稿先归档，按确认的具体行为实现，不要求再次批准同一方向；当前状态以 [DESIGN.md](../../../apps/browser-extension/DESIGN.md) 为准。

## 范围

- 已保存配置且已授权的 endpoint：点击整理立即进入编译，不请求连接测试。
- 未配置：保留录制 ID，进入设置，保存后继续同一录制。
- 首次发送：现有 Dialog 展示 endpoint 和模型，取消不请求模型、不记住授权；确认后由后台记录当前脱敏协议版本的授权。
- 授权只属于规范化 endpoint，可在模型设置取消勾选并保存；不扩大录制范围，不允许自动采集或自动整理。
- 鉴权/接口或模型不存在/请求配置错误进入设置，顶部 Toast 说明原因，底部“保存并重试”；网络/限流/超时和输出校验失败留在任务页，用户显式重试。
- 失败修复保留源录制，直接开始与确认请求防重入；后台每次重新核对授权。任务开始不隐式覆盖保存的模型配置。
- 布局继续使用当前 Box、满宽 ScrollArea、固定外框、密钥状态与顶部 Toast；图内装饰和字号比例不是额外实现要求，实际控件沿用现有样式。

## v1 提示词

```text
Create ONE coherent four-state UI review board for Dr.Octopus browser extension's user-approved direct recording-to-workflow flow. Four equal 360x600 logical-pixel popup screens, aligned, crisp Simplified Chinese, preserve existing flat near-black/charcoal shadcn styling, neutral gray borders, 16px INTERNAL content Box padding, fixed brand/tabs/navigation/footer, full-width body scroll area only. Use attached approved board for style. No gradients/new design direction. Date 2026-10-29. Board title: 一键整理 · 首次授权与失败恢复.
All frames: brand Dr.Octopus with outline plug, 浏览器连接 · Google Chrome subtitle; segmented tabs 连接 / 录制 / 工作流, 工作流 active.
Frame1 正常路径: ← 整理为工作流. Body simple existing task panel heading 正在整理步骤与参数…; synthetic recording name 订单查询录制; muted service host api.example.test. A small spinner and brief 可关闭弹窗，稍后回来查看。 Fixed outline 取消任务 button. No model settings form, no connection test, no extra confirmation for an already-authorized endpoint.
Frame2 首次使用此接口: same shell with quiet workflow context behind a compact accessible AlertDialog centered inside popup, dim backdrop. Dialog title 允许发送脱敏录制？ Description 将脱敏后的录制发送至以下接口，用于生成工作流。 Monospace wrap-safe example https://api.example.test/v1 and model example-model. Brief muted note 此接口的后续整理不再重复询问，可在模型设置撤销。 Buttons 取消 outline and 允许并整理 white solid. No automatic request before clicking; no extra model test. This is a small confirmation, not settings.
Frame3 配置修复: ← 模型设置. TOP floating red Alert toast just below navigation: 鉴权失败，请检查 API Key。 with dismiss x. Do not push form down. Fields 提供商 [OpenAI 兼容] read-only; 接口地址 [https://api.example.test/v1]; API Key neutral saved row lock 已保存 / 更换 / 清除; 模型 combobox [example-model ▾] with solid 拉取 button. A checked checkbox below fields 允许向此接口发送脱敏录制 (can revoke by unchecking and saving). Footer 测试连接 outline + 保存并重试 white solid. Only body scrolls at right edge when needed. Original recording context retained, no workflow replay.
Frame4 临时失败: ← 整理为工作流. Heading 整理未完成, synthetic name 订单查询录制, host api.example.test. Compact red Alert 模型服务暂不可用，请稍后重试。 Preserve task context, not settings. Fixed footer white solid 重试整理 and outline 模型设置. Retry requires explicit click; no auto retries. Not all errors route to settings.
All controls readable and fit frame. Preserve top-toast and saved-key designs, no secrets or real business content, no task-history dashboard, no replay. New board records an approved functional change; no need for multiple visual alternatives.
```

原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-3c8da407-e415-4d0e-b43a-c4a14bcc5ad7.png。仓库副本 workflow-direct-compile-v1.png。首稿将已存密钥画成密码框和重复操作行，未作为目标。

## v2 修订提示词

```text
Revise this board conservatively to match the existing app, preserving the four functional states. Screen3 API Key must be ONE neutral bordered row only: lock icon 已保存 at left, small 更换 and 清除 actions at right. Remove ALL password dots, eye icon and extra saved badge row from Screen3; saved secrets are never auto-filled. Both red feedback surfaces should use the existing restrained Alert styling: very subtle dark red tint, thin red border and readable red text, not bright saturated red banners or glow. Screen1 and Screen4 simplify body into one flat panel with task state heading, plain 订单查询录制 line and muted api.example.test, no nested cards, no dates, no oversized graphics. Keep only a small spinner beside the active state text. Screen4 footer fixed to same bottom baseline as other screens, 重试整理 solid primary and 模型设置 outline. Preserve Screen2 compact confirmation dialog, wording, target URL/model, cancellation and 允许并整理. Preserve full-width body scrolling, 16px inner Box padding, fixed header/tabs/navigation/footer and all existing UI style. No new features.
```

原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-4655374d-f090-42a5-b064-5b9400b14898.png。仓库副本 workflow-direct-compile-v2.png。依据用户确认并要求实施的具体方案归档为当前目标，不声称用户逐像素审阅过生成图。所有数据均为合成示例，不是运行截图或真实客户资料。
