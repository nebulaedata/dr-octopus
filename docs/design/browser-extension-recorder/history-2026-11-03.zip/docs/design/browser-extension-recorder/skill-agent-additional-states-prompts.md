# 补充状态稿来源

2026-11-01，依已确认实施计划补齐多选、保存失败、未知结果和短窗；ImageGen生成，合成数据，非运行截图。当前权威状态见[DESIGN.md](../../../apps/browser-extension/DESIGN.md)。

v1：[原图](skill-agent-additional-states-v1.png)，来源 exec-b84a1b9c-84b0-4c61-a437-239d778ce6ad.png；状态/配色错误需修订。

v2：[修订稿](skill-agent-additional-states-v2.png)，来源 exec-5e0f7ea8-f0e4-4c72-b8e0-e48b7060403b.png；等待审阅。两原件位于 C:/Users/zhang/.codex/generated_images/01a19123-1034-7e01-b652-9e2b37c38bbc/，均原尺寸保留。

v2的静止等待/结果待核实图标实施为Clock，不使用动画spinner，不能暗示继续执行。保存失败仍属原整理会话，导航可用整理技能而不另开业务流程。

## 首稿提示词

```text
Create a faithful refinement STATE BOARD for the attached existing Dr.Octopus browser extension design, not new design directions. Four related states arranged as 2x2 grid, each logical360x600, overall logical744x1224, render sharp at proportional2x. Use DARK neutral shadcn nearblack/white/gray palette, no blue/yellow accents, only small green success/red error. Date2026-11-01. Every pane keeps selected design brand cable logo Dr.Octopus with settings gear on right, subtitle 浏览器连接 · Google Chrome, exactly2 tabs 连接状态 / 录制重放 second selected, fixed navigation and footer; only body scrolls. No free-chat input. Top left: 整理技能 waiting neutral badge, compact conversation timeline completed 读取录制 then Questionnaire question 哪些字段每次运行时填写？ with checkbox options 订单编号 checked, 查询日期 checked, 客户名称 unchecked. Footer 稍后处理 outline and 确认并继续 white. Top right: 整理技能, completed tools 读取录制, 校验技能, then inline red Alert 技能已生成，尚未保存 / Executor连接已断开。 No model retry button. Footer 返回录制 outline and 重试保存 white. Bottom left: 运行技能, completed tools 观察页面 / 点击提交 then red Alert 操作结果尚未确认 / 已停止后续操作，请先检查网页。 No repeat-action button. Footer single outline 返回录制. It must not claim action was undone, no dangerous automatic retry. Bottom right: short viewport stress example using same shell but logical popup height460 instead of600 inside the aligned600 cell, blank charcoal remaining below separate from popup; title运行技能 waiting neutral. Compact timeline工具已观察页面; current question请输入订单编号 with labelled text field 订单编号 containing000123, field small red validation message 请检查填写内容。 single right-edge body scrollbar only below nav and abovefooter; footer 稍后处理 outline and 确认并继续 white. Keep controls readable not shrunk; older timeline above fold clipped by scroll only, header/tab/footer always visible. Minimal copy, no explanatory marketing captions or giant shadows. No secrets, synthetic data only.
```

## 修订提示词

```text
Correct this FOUR-state existing board without changing layout. Top-left header badge must be 等待回答 in neutral gray, not 正在整理. Its checked checkboxes must be WHITE with black checkmarks, NOT green. Top-right badge must say 保存失败, not 整理失败; failed tool title 保存技能, green 校验技能 row subtitle 校验通过. Bottom-left badge must say 结果待核实 neutral gray, not 正在运行; 点击提交 row subtitle 点击请求已发出。 and neutral clock icon instead of green success check for that row because outcome unknown. Bottom-right badge must say 等待回答 neutral gray, not 正在运行. Keep all other Chinese, exact two tabs, fixed header/footer, same dimensions. Red alerts remain errors, genuine completed read tools may retain green checks. This is a minimal semantic and palette correction, not a new direction. Date2026-11-01.
```

