# 浏览器录制视觉稿

- 一键整理与失败恢复：[workflow-direct-compile-v2.png](workflow-direct-compile-v2.png) · [提示词与交互约束](workflow-direct-compile-prompts.md)（状态见 DESIGN.md）

- 全宽滚动与标题栏任务入口：[popup-box-task-toolbar-v2.png](popup-box-task-toolbar-v2.png) · [提示词与布局约束](popup-box-task-toolbar-prompts.md)（状态见 DESIGN.md）

本目录仅保存视觉稿图像与提示词原件。设计规范、交互契约与视觉稿权威状态登记已集中到 [apps/browser-extension/DESIGN.md](../../../apps/browser-extension/DESIGN.md)（唯一权威入口，含状态登记表与审阅记录）。

- 双 Tab 与录制详情：[候选1](recording-replay-context-actions-v1.png) · [候选2](recording-replay-command-bar-v1.png) · [候选3](recording-replay-action-shelf-v1.png) · [提示词与来源](recording-replay-actions-prompts.md)（当前状态见 DESIGN.md）

- 已选方向状态细化：[录制详情状态](recording-replay-detail-states-v1.png) · [整理会话状态](skill-organizer-session-states-v2.png) · [历史与重放状态](skill-replay-history-states-v2.png) · [提示词与修订记录](skill-agent-state-refinement-prompts.md)（当前状态见 DESIGN.md）

- 设计系统与状态登记：[apps/browser-extension/DESIGN.md](../../../apps/browser-extension/DESIGN.md)
- 融合设计（架构）：[browser-extension-recorder.md](../../architecture/browser-extension-recorder.md)
- 决策记录：[ADR-0086](../../adr/0086-browser-extension-recording-and-local-replay.md)
- 验证矩阵：[executor-validation.md](../../poc/executor-validation.md)
- 提示词与来源：[prompts.md](prompts.md) · [recording-flow-prompts.md](recording-flow-prompts.md) · [popup-wrapper-prompts.md](popup-wrapper-prompts.md) · [popup-refinement-prompts.md](popup-refinement-prompts.md) · [connection-panel-prompts.md](connection-panel-prompts.md) · [recording-pagination-prompts.md](recording-pagination-prompts.md)

- 第二阶段候选：[workflow-phase2-board-v3.png](workflow-phase2-board-v3.png) · [提示词与来源](workflow-phase2-prompts.md)（状态见 DESIGN.md）

- 步骤与参数编辑：[workflow-editor-board-v1.png](workflow-editor-board-v1.png) · [提示词与交互边界](workflow-editor-prompts.md)（状态见 DESIGN.md）

- 模型列表选择：[model-settings-model-list-v2.png](model-settings-model-list-v2.png) · [提示词与交互边界](model-settings-model-list-prompts.md)（状态见 DESIGN.md）

- 连接反馈与密钥保存：[model-settings-connection-feedback-v3.png](model-settings-connection-feedback-v3.png) · [提示词与交互边界](model-settings-connection-feedback-prompts.md)（状态见 DESIGN.md）

- 整理历史：[workflow-history-board-v2.png](workflow-history-board-v2.png) · [提示词与交互](workflow-history-prompts.md)（状态见 DESIGN.md）

- 步骤就地核对：[稿件 1](workflow-step-review-evidence-v1.png) · [稿件 2](workflow-step-review-footer-v1.png) · [稿件 3](workflow-step-review-focus-v1.png) · [交互提案](step-review-design.md) · [提示词与来源](step-review-prompts.md)

- 引导式整理：[开发设计](../../architecture/browser-workflow-guided-organization.md) · [视觉稿1](workflow-guided-question-focus-v1.png) · [视觉稿2](workflow-guided-question-evidence-v1.png) · [视觉稿3](workflow-guided-question-decisions-v1.png) · [提示词与来源](workflow-guided-prompts.md)（状态见 DESIGN.md）

- 引导式整理第2方向细化：[提问状态v2](workflow-guided-question-states-v2.png) · [继续与预览v2](workflow-guided-continuation-states-v2.png) · [提示词与修订记录](workflow-guided-refinement-prompts.md)（状态见 DESIGN.md）

- 最近/全部工作流与紧凑行：[视觉稿](workflow-recent-all-compact-v1.png) · [提示词与交互契约](workflow-recent-all-prompts.md)（状态见 DESIGN.md）

- Skill Agent 会话：[前序稿1](skill-agent-session-timeline-v1.png) · [前序稿2](skill-agent-session-focus-v1.png) · [前序稿3](skill-agent-session-tools-v1.png) · [提示词与来源](skill-agent-session-prompts.md) · [当前设计开发方案](../../architecture/browser-skill-unified-agent.md) · [交互契约与状态](../../../apps/browser-extension/DESIGN.md)（视觉稿按用户要求延后）
