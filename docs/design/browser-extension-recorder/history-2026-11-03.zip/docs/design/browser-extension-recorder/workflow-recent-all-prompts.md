# 工作流最近列表、全部列表与紧凑行设计

2026-10-31。用户要求：工作流首页“最近工作流 + 查看全部”，最近10条；搜索仅在全部工作流；沿用录制的每批20条游标加载更多；纯列表外层上下无padding，item统一8px内边距、48px最小高度，gap为0。历史/设置入口保留在首页标题栏，连接仍是扩展默认Tab。

- [视觉稿](workflow-recent-all-compact-v1.png)：pending review；唯一状态登记为[DESIGN.md](../../../apps/browser-extension/DESIGN.md)。
- 来源：内置image_gen，实际附带现有工作流/全部录制运行截图作为品牌和布局参考；使用合成名称，不包含用户截图中的业务内容。
- 原图：`C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-d7daeab6-1fae-49d4-8026-a147a90c709b.png`。
- 单个Popup逻辑尺寸360×600，画板为三个页面状态，不是三种方案。首页最多加载10条，不要求一屏塞下10条；实际超出正文高度时ScrollArea滚动，不能缩小字号。图中数量、时间为示例。

## 交互契约

- 首页不提供搜索；空数据用Empty，加载/失败分别显示Skeleton和重试。查看全部始终可达。
- 全部页搜索整个工作流集合，200ms防抖；新查询重置游标和滚动，过期回复不覆盖新结果。返回详情后保留查询、已加载范围与位置。
- 最近/全部按updatedAt倒序，同时间按ID倒序；最近10条包含草稿及已发布工作流。全部页每次20条，使用加载更多而非页码按钮。
- 编辑保存会改变排序；刷新全部页时重新读取已加载范围，不能把旧游标拼到新排序上。仅同一加载链内按ID去重。
- 当前工作流总存储上限100条保持不变；底层分页可复用有界摘要查询，不为100条数据新增数据库索引迁移。
- 纯列表正文只保留水平Box padding，上下为0。页面/表单区块保留原留白，单条记录的图文间距保留。行padding统一8px，最小高度48px，独立Separator、零item外间距。
- 仅有上下padding/行padding调整已是用户明确局部要求；新增全部工作流路由按先出稿规则等待视觉确认。此稿获批不自动改变模型调用预算或重放能力。

## 完整提示词

```text
Create ONE production-quality review board for a specified update of the EXISTING Dr.Octopus browser extension. This is one concrete design with three states, NOT three alternatives. Use attached existing popup screenshots as the exact brand/style reference. Black-white-gray DARK theme, existing brand mark and header Dr.Octopus / 浏览器连接 · Google Chrome. Three logical 360x600 popup panels, same scale, next to each other with small gutters on a neutral canvas. Output about 2240x1300, current date2026-10-31. Preserve fixed brand, tabs, navigation, full-width body ScrollArea and footer. NO padding above or below pure list body: first row starts immediately under the fixed header separator (or under fixed search field on the full-list page). List items all compact, min-height48px, horizontal8px and vertical8px padding, zero margin/gap between items. Independent straight 1px Separators, never curved row borders. Row internal title and secondary text remain readable. Do not make rows 64 or80px tall. Only content scrolls; header and footer never scroll. No giant UI typography, phone chrome, free-chat input or extra product features.
LEFT panel caption 最近工作流. 工作流 tab active. A single header row: title 最近工作流 on left; 查看全部 chevron link plus history icon and settings gear on right, all on same row. Crucially NO SEARCH FIELD on this home page. Show the top portion of 10 recent workflow rows, enough visible compact rows to imply scrolling. Example names: 订单查询流程, 提交记录查询, 文档处理流程, 客户资料核对, 发票检索流程, 报表查询流程, 项目列表查询, 审批记录查看. Each row has metadata 3步 · 1个参数, a neutral badge 已发布 or 草稿, and right chevron. First row directly touches the header separator with only its own8px padding. No footer buttons.
CENTER caption 全部工作流. 工作流 tab active. Back arrow + 全部工作流 navigation, then fixed search input with search icon and placeholder 搜索工作流. Rows same style/density as left, show several of 20 loaded. Footer fixed bottom: small centered 已加载20条 and full-width outline 加载更多. Only the full-list page has search. No numbered pagination buttons. No extra list card border/inset around rows; same list geometry as 录制全部记录 reference.
RIGHT caption 整理历史. 工作流 tab active. Back arrow + 整理历史. NO SEARCH. First compact row starts immediately after nav separator, no blank band. Rows with small status icon, title 订单查询录制, metadata 10/31 12:30 · model-demo, badge 成功 / 待回答 / 失败 and chevron; use green only success and red only failure, waiting neutral. Zero outer vertical padding and same48px minimum row density. Footer shows 已加载8条 · 最多保留200条已结束记录, no load button when no more. This panel demonstrates unified compact list item spacing, not a new history feature.
Use synthetic data only and exact Chinese labels. Keep history/settings actions in the home title row, not separate button rows. Preserve typography and icons from the references; no giant section cards.
```


2026-10-31后续审阅：用户明确确认“按此稿接入”，状态已登记approved，前端实施获授权；上文pending review为生成时记录。

后续用户明确局部修订（2026-10-31）：列表外层py-2、列表Separator my-2；查看全部放标题栏最右侧（整理历史、模型设置在其左）。录制已整理和工作流列表已发布采用success绿色，其余状态保留原样。以上覆盖原图对应的无上下留白、按钮次序和中性成功Badge区域；原图保持不覆盖，状态登记仍以DESIGN.md为准。
