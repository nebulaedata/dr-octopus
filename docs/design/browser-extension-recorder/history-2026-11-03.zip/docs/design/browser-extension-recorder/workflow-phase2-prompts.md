# 第二阶段视觉稿提示词与来源

生成日期：2026-10-28。使用内置 imagegen，所有数据均为合成示例。现有连接页与 DESIGN.md 为风格依据；本稿为设计概念，不是已实现 UI。当前状态仅以 apps/browser-extension/DESIGN.md 为准。

## v1

文件：workflow-phase2-board-v1.png。生成四屏合稿：模型设置、整理进度/失败、参数审阅、工作流列表。问题：Tab 样式、品牌图标与彩色徽章偏离现有规范。

```text
Create one high-fidelity UI review board with FOUR adjacent full browser extension popup screens, each 360x600 logical pixels, exported large for readable Simplified Chinese. This is a coherent single design artifact, not alternative directions. Dr.Octopus dark neutral shadcn style matching reference: near-black background, charcoal cards, thin gray borders, restrained rounded corners, white main text, readable gray secondary text, system Chinese sans-serif, minimal outline icons. No gradients, decorative illustrations or colored accents except small error text. All screens retain the fixed top Dr.Octopus plug-icon brand header, subtitle 浏览器连接 · Google Chrome, tabs ordered 连接 / 录制 / 工作流. Show 工作流 selected. Fixed navigation bar below tabs, slim ScrollArea only inside body, fixed bottom action footer outside scroll. White solid primary buttons with dark text; destructive actions secondary and separated. Comfortable dense layout, minimal helper text.
Screen 1 navigation ← 模型设置. Form 提供商 [OpenAI 兼容 ▾], 接口地址 [https://api.example.com/v1], 模型 [example-model], API Key [•••••••• eye icon]. Only one concise helper: 密钥仅供本次任务使用. A compact neutral connection status row 尚未测试. Bottom outlined 测试连接 and solid 保存配置. No remember-key option. No real credentials.
Screen 2 navigation ← 整理为工作流, badge 整理中. Card 订单查询录制, 12 步 · 2 个页面. Vertical progress: 已读取录制 check; 正在整理步骤 spinner; 待生成参数 empty. Simple note 可关闭弹窗，稍后回来查看. Lower subtle privacy line 脱敏后的操作记录将发送至 api.example.com. Bottom outlined 取消整理. Leave calm whitespace; no fake percentage. Tiny inset state card within body for error variant: 整理失败 / 服务暂时不可用 / 重试 button, clearly labelled 失败状态示例 outside the main phone canvas.
Screen 3 navigation ← 审阅工作流, badge 草稿. editable 名称 [订单查询]. Two compact sub-tabs 步骤 / 参数 with 参数 selected. Card 订单号 with text type badge 必填 and input 变量名 orderNo, 使用位置 第 2 步 · 填写订单号. Another neutral section 待确认建议 with unchecked checkbox 读取查询结果 and small 模型建议 · 未直接录制 badge. Compact section 成功条件 查询结果与订单号对应. Footer outline 保存草稿 and solid 确认并发布. No execute/run button.
Screen 4 navigation 工作流 with gear icon button 模型设置. Fixed search 搜索工作流. List of clickable rows: 订单查询 badge 已发布, 4 步 · 1 个参数, chevron; 客户信息核对 badge 草稿, 待审阅, chevron. White hover fill only charcoal modest highlight. Large remaining space natural. Footer no runtime controls. Label entire board 第二阶段 · 待审阅, and label each screen externally. Preserve elegant existing utility extension style. No playback feature shown as available.
```

## v2

文件：workflow-phase2-board-v2.png。以 v1 为编辑输入；修正分段 Tab、单色徽章、提交按钮和发送数据确认。仍有模型设置页错误选中连接 Tab 的问题。

```text
Revise this four-screen Dr.Octopus UI board, preserving the screen content and overall arrangement. REQUIRED corrections: all four top tab bars must match the existing extension's pill segmented control: charcoal rounded full-width container, selected segment slightly lighter charcoal with thin gray border; NO underline navigation. Replace all puzzle-piece logos with simple plug-and-cable outline icon in a rounded charcoal square. All badges monochrome gray, NO blue, green or amber badges. Retain red only for failure. Remove ellipsis header menus. Model settings primary action should say 保存并继续, secondary 测试连接; below API Key only 密钥仅供本次任务使用. Distinguish parameter editor's bottom actions: 保存草稿 must also be solid white since it saves data, 确认并发布 solid white, equal height; concise labels. Keep three visible tabs 连接 / 录制 / 工作流. Fixed top brand and tabs, fixed subpage navigation, fixed bottom actions; body thin gray scrollbar. No shadows inside popup. Remove the extra per-step explanatory small gray sentences on progress screen; only the three status labels. Remove redundant instruction under 尚未测试. Show data-sending notice BEFORE compilation as a simple one-line consent checkbox above the footer on model settings: 允许发送脱敏操作记录. On compilation screen retain concise provider-domain text. Preserve exact four screens, existing readable Chinese, black/white/gray aesthetic. Label board 第二阶段 · 待审阅. Do not add playback controls or features. Keep no overwriting indications.
```

## v3

文件：workflow-phase2-board-v3.png。以 v2 为编辑输入；修正模型设置所属 Tab。候选覆盖配色、布局、固定外框、表单和审阅层级；普通文案允许按实际功能调整。

```text
Make exactly one correction to this UI board: in the LEFTMOST model settings screen only, make 工作流 the selected tab (same light charcoal segment and border as the other three screens), and make 连接 unselected. Preserve every other pixel's layout, all four screens, monochrome colors, text, card structure and buttons as closely as possible. This is the third revision of one design artifact, not new alternatives.
```

## 流程约束

- 默认打开仍是连接 Tab；图中工作流选中态表示用户已进入工作流功能。
- 模型设置由工作流页齿轮入口或录制详情的整理动作进入；首次整理前确认发送的提供商域名，API Key 只转交受信 Host 内存。单独编辑设置时不自动发起编译，保存并继续仅用于整理前置流程。
- 编译失败与取消不删除原始录制，重试是明确的新任务，不静默重复发送；关闭 Popup 不结束 Host 中任务。
- 编译进度按真实任务状态展示，图中的三个阶段不要求虚构模型内部进度；整理由模型完成时显示不定进度。
- 模型测试与保存互不冒充；测试连接将发起真实提供商请求，可能计费，需用户显式点击。
- 保存草稿不发布；推断、缺口和成功条件必须审阅，发布只表示可供未来运行，不代表已执行成功。第三阶段前不提供可点的运行按钮。
- 所有顶部栏和底部操作固定，只有正文滚动。列表支持 Empty、加载与错误状态。错误示例为独立状态，不与正常进度同时叠放。
- 后续补齐步骤编辑、缺口审阅、空态及失败状态的细化稿；v3 不自动授权未展示的详细布局。

