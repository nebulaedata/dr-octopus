# 全宽 ScrollArea、Box 与整理任务标题栏

日期：2026-10-29。用户确认外层不设 padding、内容块统一 Box padding，并确认将最近一次整理入口放到设置旁，明确要求开始开发。本次按已确认方案先生成并归档实施参考图，不新增产品方向或等待重复授权。图像是合成设计稿，不是运行证据；权威状态见 [DESIGN.md](../../../apps/browser-extension/DESIGN.md)。

## 参考与范围

参考本轮对话中用户提供的模型设置、录制首页和工作流空态截图，保持黑灰色系与固定外框。输出使用示例站点、文档示例 IP 和合成记录。v1 的滚动条越过固定导航、无溢出区域仍有滚动条等问题已在 v2 修正；首稿保留，不作为实施目标。v2 只定义外框、内容间距及标题栏任务入口，其他已批准业务细节继续采用各自稿件。

- `Box` 仅负责默认 16px padding，不加默认背景、边框或圆角。品牌/Tab/导航/正文/footer 各自承担内边距；正文 Box 在 ScrollArea 视口里面。
- 正文 ScrollArea 占满 360px 宽度，滚动条贴近最右侧；只滚动正文，不带动顶部或 footer，无溢出不显示滚动条。
- 字段和卡片仍距左右边缘 16px，取消旧外层 padding 与正文 pr-3 的叠加，让外扩焦点位于视口内部。
- 任务按钮在工作流标题栏、设置图标之前。进行中 spinner + 整理中，终态为图标及 Tooltip，失败/中断有状态点，取消为中性状态。
- 没有录制来源的旧连接测试不显示任务入口，不删除旧存储，也不新增任务历史、重放或自动执行功能。
- 全部页面共用布局，保留已有列表滚动恢复、固定搜索、导航、模型顶部 toast、默认连接 Tab 和真实 action 弹窗尺寸。

## v1 原始提示词

```text
Create ONE coherent implementation reference board for the user-approved Dr.Octopus extension layout refinement. Four 360x600 logical-pixel popup screens aligned, large crisp CJK output. These are states of the SAME existing product, not alternative styles. Use attached current UI screenshots as visual style references; ignore red annotation rectangles and replace all names/URLs with synthetic samples. Preserve flat near-black/charcoal backgrounds, thin neutral borders, rounded shadcn controls, white/gray text, Dr.Octopus plug brand tile, 浏览器连接 · Google Chrome subtitle, top segmented tabs 连接 / 录制 / 工作流. Date anchor 2026-10-29.
Key mandatory shared layout: OUTER popup frame has ZERO padding; each region has its OWN internal 16px horizontal Box padding. Header and tabs still look identically inset 16px. Header, tabs, navigation and footer fixed. The BODY SCROLLAREA spans the entire 360px width, with a slim gray scrollbar flush at the right popup edge x~354, NOT inset beside the cards. Only inner scrolling content gets 16px padding all around. Cards and form inputs span x16 to x344. Focus outlines have visible breathing room inside viewport, never clipped. Do not draw Box borders or labels inside UI. The Box is invisible spacing only.
Board title outside: 全宽滚动与标题栏任务入口.
Screen 1 caption 录制 · 全宽滚动: top 录制 tab selected; body long scrollable content beginning with 新建录制 card, synthetic site 示例订单 / https://orders.example.test, checkbox 同时录制从当前页面打开的新标签页, white 开始录制 button; below 最近录制 heading with 查看全部 small action, 4 clickable rows 订单查询流程 / 客户资料核对 / 发票查询 / 库存查看 with date/steps. Gray scrollbar on far-right OUTSIDE inner 16px spacing, body only. No footer needed.
Screen 2 caption 模型设置 · 完整焦点: 工作流 active, fixed ← 模型设置 navigation; form 提供商 [OpenAI 兼容], 接口地址 [http://192.0.2.10:4000/v1] focused with neutral gray 3px focus ring FULLY visible on all sides; API Key masked input with eye icon, 模型 [qwen3.5-flash ▾] plus white 拉取 button. Minimal helper 保存配置后保留在此浏览器. Fixed bottom 测试连接 outline and 保存配置 solid white buttons. Show slim body scrollbar at rightmost edge, NOT inside form padding. No toast.
Screen 3 caption 工作流 · 整理中: 工作流 active; fixed title row 工作流 left, compact spinner + 整理中 ghost button right immediately before gear settings icon. Fixed search input 搜索工作流 below title divider. Body shows clickable list with synthetic workflows 订单查询 / 库存核对, small 已发布/草稿 neutral badges and chevrons. NO standalone 查看最近任务 or task button row in body. Keep title text and compact toolbar fitting 360px width.
Screen 4 caption 工作流 · 最近整理: same title/search layout as screen3, but compact neutral History/clock-arrow icon button immediately BEFORE gear (no spinner or text label). A small restrained red dot at that icon's corner indicates failed/interrupted latest compilation. Body Empty component 文件 icon and 暂无工作流 centered. NO large recent-task button. Include tiny OUTSIDE-frame annotation: 无整理任务时隐藏任务入口；仅整理任务，不包含连接测试. Tooltip 最近一次整理 may be shown as an OUTSIDE-board callout, not a permanent UI label.
All content alignments, grayscale palette and sizing match supplied real app. Never shift top fixed areas while scrolling. No new sidebars, execution buttons, task history lists, replay controls, or decorative shadows. This is a precise layout refinement authorized for development; no technical implementation text inside product UI.
```

原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-f7b3dd0a-e9b7-400a-9654-d1d7d4948283.png；仓库副本 popup-box-task-toolbar-v1.png。

## v2 修订提示词

```text
Correct the attached review board only in these specific regions. Scrollbars belong ONLY to scrolling body, never fixed navigation/search: Screen1 retain far-right scrollbar beneath tabs. Screen2 move scrollbar TOP down to below the 模型设置 navigation divider (approximately image y=292), bottom stays ABOVE footer buttons. Screens3 and4 have only two rows / empty data, so REMOVE their scrollbars entirely; no scrollbar when no overflow. Remove dropdown chevron from Screen2 read-only 提供商 OpenAI兼容 field. Replace Screen1 开始录制 spinner icon with a small mouse-pointer-click outline icon; it is not busy. Keep active 整理中 spinner in Screen3. Preserve everything else: fixed header/tabs/navigation/search/footer, full-width body scroll container with 16px INNER content padding, unclipped model endpoint focus ring, title-row task button next to gear, grayscale and four equal frames. Do not change fields or add any extra buttons. These are mechanical corrections to an approved layout plan, not a new direction.
```

原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-58b1af0d-b43e-438d-bbf9-a5670f905eb1.png；仓库副本 popup-box-task-toolbar-v2.png。按用户确认的具体方案作为实施参考，不声称用户逐像素审阅过新生成图。
