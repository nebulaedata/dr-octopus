# Popup 固定外框与交互反馈：完整提示词

日期：2026-10-27。工具：内置 Image Gen。当前状态以 [README](README.md) 为准。参考为用户提供的三张带批注截图，生成时明确移除批注并使用虚构页面和数据；用户原截图不作为可发布素材归档。

首页 v3、详情 v5、空态 v1 已于 2026-10-27 获用户批准；当前状态仍以索引为准。详情 v4 误给只读步骤添加箭头，已由 v5 修正，保留用于追踪。图中尺寸与静态滚动位置只是设计目标，不能代替实际交互验收。

## recording-start-v3.png

原始文件：`exec-8815f80e-e704-41c2-b571-b4fdba4013fc.png`。

```text
Create ONE revised production-quality Dr.Octopus browser extension popup UI mockup grounded in the THREE attached user screenshots. They are actual dark-mode UI with red review markup; REMOVE all red annotations, do not reproduce private website titles, domains or recorded content. Use fictional orders.example.com and generic record names. Screen: 录制首页固定外框与列表悬停. Natural 360x600 logical px, crisp 3x output. Dark shadcn-neutral palette exactly like screenshots: nearly black base #0a0a0a, charcoal card surfaces, subtle gray borders, white default primary button, pale text, fine Lucide icons, Chinese system font, 14px body and 12px metadata. ONE screenshot, not a collage or explanatory diagram, no browser/device frame. Top fixed wrapper region from y0 to about y110 contains cable icon in rounded square, Dr.Octopus / 浏览器连接 · Google Chrome, tabs 连接 FIRST / 录制 SECOND active / 工作流 THIRD disabled. Below top tabs a subtle fixed separator; header and tabs have NO scrollbar beside them. Only the content region below that separator has a thin rounded shadcn ScrollArea-style gray thumb, inset from the right, beginning below the tabs and ending at the content bottom. No browser native whole-window scrollbar. Show content at top position: card 新建录制 with current-page row 订单管理 / orders.example.com, then one unchecked checkbox label 同时录制流程打开的同窗口已授权页面. It may wrap naturally as ONE label in same text color; NO second helper description line. One white full-width default button with mouse-pointer-click icon 开始录制. Below card title 最近录制 and right quiet 查看全部 chevron link. List of at least three rows: 查询订单状态 / 8 步 · 今天 / 已保存; 更新客户资料 / 6 步 · 今天 / 部分保存; 导出销售报表 / 12 步 · 昨天 / 已保存. Every row has a visible right chevron. Show the FIRST row hovered, with a subtle lighter charcoal background across entire row, slightly brighter text/chevron and a normal small hand pointer near its title. Do not use a big cursor illustration. List rows have dividers, not oversized separate cards. Lower content can extend below scroll viewport, but header remains fully visible. No search box on recent-five homepage. No repetitive local-save/Executor disclaimers or extra descriptions. Keep sensible compact spacing, fixed viewport boundary and clear clickable affordance. Current date October 27 2026. Precise Simplified Chinese. Visual draft only, no implementation claim.
```

## recording-detail-v4.png

原始文件：`exec-02ad36a7-ba85-4f98-a5a0-396e9cc12723.png`。

```text
Create ONE revised Dr.Octopus dark-mode recording-detail popup UI mockup using the attached original user screenshots for style and the newly generated dark recording homepage for the matching shell. Ignore red review annotations and never copy real website titles, private domains or user record content. Screen: 录制详情固定导航与内容独立滚动. Natural 360x600 logical pixels, sharp 3x. ONE screen, no collage, diagram, browser chrome or device. Dark neutral shadcn palette: near-black background, charcoal surfaces, fine gray borders, white text, muted secondary text, rounded compact controls, Chinese system font logical 14px body and 12px metadata. TOP FIXED WRAPPER contains cable icon Dr.Octopus / 浏览器连接 · Google Chrome, tabs 连接 first / 录制 second active / 工作流 third disabled, then the unified NavigationBar with ghost back-arrow, title 录制详情, right neutral 部分保存 badge, thin bottom separator. The brand header, tabs and navigation remain fully visible. Their right edge has NO scrollbar. Only the BODY region BELOW NavigationBar and ABOVE fixed footer uses a slim rounded custom ScrollArea thumb; thumb positioned around the middle to show the content has been scrolled. Do NOT draw a native window scrollbar. Show body in a mid-scroll state: name field and save controls are already scrolled above viewport and are NOT visible. Body begins with a compact 操作步骤 heading, 12 步 right. Flat chronological list with visible rows 4 打开订单详情 / 订单列表; 5 展开订单信息 / 订单详情; 6 填写备注 / 已隐藏输入值; 7 确认筛选条件 / 订单详情; 8 查看处理记录 / 订单详情; next row partly continues below viewport. Appropriate thin line icons, quiet row separators, no raw codes or URLs. FIXED bottom footer below content with full-width shadcn destructive button 删除录制, pale dark-red tint and red trash icon/text. Footer is outside scroll viewport and always reachable. No constant disclaimer paragraphs or large warning block. No unnecessary toolbar, no sidebar, no workflow action. Current date October 27 2026. Preserve approved component vocabulary and polished compact spacing. This is a visual proposal for scroll boundaries, not an implemented UI screenshot.
```

## recording-detail-v5.png

原始文件：`exec-561c41fc-1499-432b-b2a0-5f883c7a56d7.png`。

```text
Edit ONLY the most recently generated Dr.Octopus dark recording-detail mockup. Preserve the fixed brand header, tabs, NavigationBar, body-only scrollbar, scrolled position, timeline text, colors, spacing and fixed destructive footer exactly. REMOVE every right-pointing chevron from the individual operation-step rows. Those rows are read-only evidence, not navigable objects, and must not imply a click action. Keep the back arrow in NavigationBar. Do not add replacements or any other controls.
```

## recording-empty-v1.png

原始文件：`exec-ae944865-5e44-47cd-8577-13338c89e331.png`。

```text
Create ONE production-quality Dr.Octopus popup mockup in the same dark shadcn-neutral design as the attached refined homepage. Screen: 全部记录搜索空状态. One logical 360x600px popup, crisp 3x. No collage, device/browser chrome or decorative backdrop. Near-black background, charcoal surfaces, subtle gray border, white text, Chinese system font, fine line icons, compact 14px body/12px metadata. FIXED outer header shows cable icon, Dr.Octopus / 浏览器连接 · Google Chrome, tabs 连接 first / 录制 second active / 工作流 third disabled. Below it FIXED NavigationBar back-arrow + 全部记录 with thin separator. A search input stays fixed beneath NavigationBar with magnifying glass and entered text 库存核对. Below search, the remaining content region hosts a shadcn Empty component composition: small search outline icon in 32px muted rounded square, restrained centered title 未找到匹配的录制, and a small white default button 清空搜索. No unnecessary explanatory paragraph, no giant illustration, no dashboard cards, no workflow notices. Empty state sits centered within available CONTENT region, not over the header. There is no overflow, so do not draw any scrollbar thumb or fake track; future results use the SAME content ScrollArea below the fixed search. Do not show 已加载 0 条, 加载更多 or disabled pagination when empty. Exactly one useful empty-state action clears the query without leaving this page. Preserve flat surfaces and spacing consistent with approved extension style. Current date October 27 2026. All text Simplified Chinese. Concept design only.
```
