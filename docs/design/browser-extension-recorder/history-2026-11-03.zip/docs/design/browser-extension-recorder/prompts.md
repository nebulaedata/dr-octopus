# 视觉稿提示词与来源

> 本文件只记录生成来源与历史审批；当前可用、需修订和弃用状态统一以 [视觉稿登记](../../../apps/browser-extension/DESIGN.md)（apps/browser-extension/DESIGN.md 附录 A）为准。
> 后续录制流程补充稿的完整提示词与修订关系见 [recording-flow-prompts.md](recording-flow-prompts.md)。

生成工具：内置 Image Gen。日期基准：2026-10-27（Asia/Shanghai）。本文件记录设计约束与提示词摘要；已有稿的完整调用文本保留在本次对话中，不将摘要伪称为逐字原始提示词。后续新增稿记录最终发送的完整提示词。

## 已有稿：提示词摘要

| 项目文件                      | 原始生成文件                                  | 提示词摘要                                                                                                                                                                           |
| ----------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| recording-popup-v1.png        | exec-903f41ba-f0f4-43e0-9ccc-97ff104b4cfd.png | 连接与录制分区；单张 360×560 Popup 设计，按 3 倍清晰度生成；原始截图为样式依据；黑白灰、黑色按钮、中文系统字体；录制/工作流/连接导航；录制计时、最近步骤、暂停、停止保存及连接状态。 |
| page-recording-toolbar-v1.png | exec-9c08b735-ce7b-44a9-980d-9d62116a33b6.png | 以已选第三版为参考；单张桌面页面工具栏设计，目标视口 1440×900；订单详情示例背景；拖动柄、录制状态、计时、步骤、参与页面、暂停、停止保存、收起；不显示 Popup 或聊天界面。             |
| model-settings-v1.png         | exec-5b1a209c-12a9-4e66-8bdb-a4d2cef75d40.png | 以第三版为参考；模型/录制/数据设置分区；目标 360×600 Popup，按 3 倍清晰度生成；接口类型、服务地址、掩码密钥、模型、测试连接、保存配置；默认编译与重放共用模型，密钥仅用于任务。      |
| recording-scope-v1.png        | exec-3557b879-2245-496d-b8c3-dbcaa2bcf80e.png | 以第三版为参考；目标 360×560 Popup，按 3 倍清晰度生成；参与页面列表、当前未加入页面、显式加入操作、关联新页开关与允许站点；不自动采集无关页面。                                      |

以上尺寸是提示词目标，不是对生成图精确像素或已实现布局的验收结论。

## 本轮新增稿：完整提示词

### page-recording-toolbar-collapsed-v1.png

原始文件：`exec-4c885272-4286-422a-aabf-8225b40beeab.png`。生成工具：内置 Image Gen。历史审批：2026-10-27 获批。当前生效状态以 [README](README.md) 为准。

```text
Create ONE production-quality UI mockup continuing the selected Dr.Octopus design. Reference images: recording-popup-v1 defines monochrome product styling; page-recording-toolbar-v1 defines the webpage context and expanded toolbar. Screen: 收起后的录制工具栏. One desktop webpage viewport 1440x900, no collage or alternative states. Preserve the reference's white surfaces, fine gray borders, black buttons, rounded 12px corners, thin outline icons and Chinese system font. Show the same restrained fictional order-details webpage with anonymous sample data, no customer names or personal details. Do not show a browser window frame or OS controls. In the upper right, 20px inset, place a genuinely compact floating recording strip about 300x44 logical pixels, with six-dot drag handle, steady red recording dot, text 录制中, elapsed timer 02:34, a separator, pause icon button, black stop-square button, and expand chevron. All icon targets at least 28x28 with clear spacing. This is COLLAPSED toolbar: omit step count, page count, menu labels and full-width text buttons. It remains visible and provides immediate pause/stop without reopening popup. No close X, no full-screen overlay, no obstruction of primary webpage controls, no orange or blue extension accents. Keep underlying page visually quiet, avoid fake charts or metrics. Current date October 27 2026. Accurate readable Simplified Chinese. This is a design mockup, not a screenshot of implemented software.
```

### recording-saved-v1.png

原始文件：`exec-de11a2d9-8d2a-44de-8df1-cdfc31a71494.png`。生成工具：内置 Image Gen。历史审批：2026-10-27 获批。当前生效状态以 [README](README.md) 为准。

```text
Create ONE production-quality UI mockup continuing the selected Dr.Octopus popup in the reference image. Screen: 录制已保存. One focused browser extension popup, logical 360x520px rendered sharply at 3x. No collage, browser chrome, device or presentation backdrop. Match white background, black primary button, pale gray surfaces, fine borders, 12px corners, restrained outline icons, 14px body/12px secondary Chinese system type. Header cable icon, Dr.Octopus, subtitle 浏览器连接 · Google Chrome, settings icon. Under header the established segmented navigation 录制 selected / 工作流 / 连接. Main content starts with small monochrome check-circle icon and heading 录制已保存, helper 已保存在此浏览器，可稍后继续整理. Editable name field labeled 名称 with value 查询订单状态 and small pencil icon. A simple metadata line 8 个步骤 · 2 个页面 · 02:34. Under a fine divider show three tidy preview rows with outline icons: 填写订单号, 点击查询, 打开订单详情. Then quiet link 查看全部步骤 →. A neutral pale-gray notice 未配置模型 with secondary text 不影响保存，配置后可整理为工作流. One full-width black primary button 配置模型并整理. Beneath it a quiet secondary text action 稍后处理. No automatic run, no false compilation success, no celebratory illustration, no raw event JSON, no deletion on close, no scary warning colors. Distinguish recording saved from workflow compiled. Current date October 27 2026; no additional dates needed. Preserve compact realistic extension proportions, generous but practical spacing, accurate Simplified Chinese. This is visual design, not a working UI.
```

### model-settings-error-v1.png

原始文件：`exec-fb2925c1-893a-4168-9fb5-552f887407ca.png`。生成工具：内置 Image Gen。历史审批：2026-10-27 获批。当前生效状态以 [README](README.md) 为准。

```text
Create ONE production-quality UI mockup continuing the attached Dr.Octopus model-settings visual reference. Screen: 模型连接失败. One focused extension popup, logical 360x600px at crisp 3x. No collage, browser frame, device or presentation background. Preserve white/black/neutral-gray shadcn-like styling, fine borders, rounded inputs, Chinese system typography at logical 14px body and 12px metadata, 16px padding. Back arrow and 设置 header, cable icon right. Existing tabs 模型 selected / 录制 / 数据. Heading 模型连接, helper 用于整理录制与运行工作流. Preserve user's form entries: interface OpenAI 兼容接口, endpoint https://api.example.com/v1, masked API Key with eye icon, model demo-agent in a combobox. Show a compact pale-red inline error immediately below API Key: red outline info icon, 密钥验证失败; subtext 请检查密钥是否正确，以及是否有模型访问权限. Only this field gets a subtle red outline; other fields remain neutral. Tiny helper 仅用于本次任务，不保存密钥. Below model show collapsed 高级设置. Above footer a neutral sentence 录制已保留，修正配置后可继续整理. Footer: outlined 重新测试 and black 保存配置. Explain in small footer 保存不会自动开始整理. Saving valid-form configuration remains distinct from a successful connection test, so do not falsely show Connected or automatic execution. Hide raw HTTP response, request IDs and stack traces behind quiet 查看详情 disclosure next to error text. No modal blocking form, no full red page, no provider billing promotion, no retry spinner or success badge. Use sample endpoint/model, no real secrets. Keep realistic popup density and accurate Simplified Chinese. Current date October 27 2026. This is a design mockup only.
```
