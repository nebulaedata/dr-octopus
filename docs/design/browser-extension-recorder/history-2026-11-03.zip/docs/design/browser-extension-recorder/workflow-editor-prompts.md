# 步骤与参数编辑细化稿

日期：2026-10-29。使用内置 imagegen；参考已批准的 workflow-phase2-board-v3.png，生成四屏合稿 workflow-editor-board-v1.png。数据均为合成示例，属于设计稿，不是实现截图。首次生成任务的工具会话在对话中断后不可读取，但生成结果已保存在默认目录并找回；没有重复生成。当前状态以 apps/browser-extension/DESIGN.md 为准。

## 原始提示词

```text
Create one coherent high fidelity four-screen UI review board for Dr.Octopus browser extension, four 360x600 logical-pixel popup screens side by side, exported large with crisp Simplified Chinese. Use attached approved board ONLY as a style reference. Match its plug outline brand icon, Dr.Octopus header, gray subtitle 浏览器连接 · Google Chrome, segmented rounded dark charcoal top tabs 连接 / 录制 / 工作流 with 工作流 selected in all screens. Flat black/white/gray shadcn utility style, restrained 12px corners, thin gray borders, white text, readable muted text. No gradients, no decorative graphics, no colored badges, red only for inline validation error. Header, tabs, NavigationBar and bottom buttons stay fixed; only content shows a slim gray ScrollArea scrollbar. Minimal helper copy, no technical source UUIDs. Board title 第二阶段 · 步骤与参数编辑 · 待审阅.
Screen 1: Navigation ← 编辑工作流, badge 草稿. Name field [订单查询]. Small segmented secondary tabs 步骤 selected / 参数. Clickable list rows with numbered icon and chevron: 1 填写订单号 / 填写 · 订单列表; 2 查询订单 / 点击 · 订单列表; 3 读取查询结果 / gray badge 模型建议. A small muted section 1 个参数 · 3 个步骤. Bottom two SOLID WHITE default buttons 保存草稿 and 确认并发布, publish disabled gray until review complete. No run button and no drag affordance.
Screen 2: Navigation ← 编辑步骤, badge 第 2 步. Form: 目标说明 [查询订单]; read-only compact row 操作类型 点击 / 所属页面 订单列表; editable 定位描述 [查询]; 依赖步骤 [第 1 步 · 填写订单号 ▾]; checked checkbox 执行前确认 (mandatory read-only); compact collapsible 来源证据 · 1 条, beneath it a small record 点击「查询」. Bottom outline 取消 and solid white 应用修改. Do not expose editing of source facts or action type. Only source rows are read-only, the main list can be entered for editing.
Screen 3: Navigation ← 编辑参数. Field 显示名称 [订单号], field 变量名 [orderNo], field 类型 [文本 ▾], field 来源 [运行时填写 ▾]. Horizontal checkboxes 必填 checked; 敏感信息 unchecked. Compact usage section 使用位置 [第 1 步 · 填写订单号]. Bottom outline 取消 and solid white 应用修改. No input for actual business values or default secret values.
Screen 4: Navigation ← 编辑参数. Field 显示名称 [订单状态], field 变量名 [orderStatus], field 类型 [选择项 ▾], field 来源 [运行时填写 ▾]. Field 可选值 textarea empty with thin red border, placeholder 每行一个选项. Small red error 请至少填写一个选项. 必填 checked; usage location 第 2 步. Bottom outline 取消 and visibly disabled solid gray 应用修改. This is an alternate validation state, no warning wall.
Keep all four frames aligned and all controls fitting 360px width. Normal body font around14px labels12px. Exact copy is illustrative; prioritize palette, layout, hierarchy, accessibility and consistent controls. No Chrome browser frame, no sidepanel/chat, no playback.
```

## 拟定交互边界

- 编辑页顶部品牌、Tab 与导航固定，正文使用 ScrollArea；操作区固定。点击编辑行进入子页，来源事实仍只读，不给只读证据增加编辑暗示。
- 子页「应用修改」只更新当前编辑中的工作副本；主页面「保存草稿」才写入 IndexedDB 并增加 revision。应用失败保留表单内容，原工作副本不部分更新；返回/取消有未应用内容时确认放弃。
- 参数字段包括显示名称、变量名、类型、来源、必填与敏感标记。选择项类型需要非空选项；来源为步骤输出时需选择真实前置步骤并具备依赖路径；敏感参数仅允许用户输入。未使用参数与断开的引用阻止应用/保存。
- 参数改名同步修改 inputRefs、usedBy 和成功条件中的 inputRef，不修改参数的真实运行值，也不提供秘密默认值输入框。
- 步骤可编辑目标说明、定位描述、参数绑定、依赖和已有输出键；动作类型、所属逻辑 Tab、来源事件与推断来源只读。强制确认的动作不能关闭确认。
- 已录制步骤不可直接删除；未被引用的模型推断建议可删除。参数删除必须明确同时解除/改绑所有引用，不自动丢弃使用方。重排只允许不违反 DOM 顺序、标签页创建/关闭和依赖约束的结果；本图未展示重排/删除入口，相关控件后续需细化，不能仅凭本图实施未展示交互。
- 应用编辑不等于审阅通过；保存后原审阅状态失效，仍需确认推断、缺口和成功条件再发布。
- 文案可按实际功能调整，视觉验收关注配色、布局、层级和交互；沿用根目录文案弹性规则。
- 本稿不涵盖重放、导入导出、复杂分支或任意新建动作。

