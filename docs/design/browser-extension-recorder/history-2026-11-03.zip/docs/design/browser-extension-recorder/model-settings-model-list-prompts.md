# 模型设置：模型列表选择细化稿

日期：2026-10-29。用户已确认 Combobox + 拉取按钮的交互方向；本图为同一方案的多个状态，不是多组选型。使用内置 Image Gen，参考对话中用户提供的当前深色 Popup 截图及仓库 workflow-phase2-board-v3.png。图片为合成视觉稿，不是运行截图；服务地址使用文档示例 IP，密钥仅为圆点占位。当前审阅状态以 apps/browser-extension/DESIGN.md 为准。

当前审阅稿：model-settings-model-list-v2.png；首稿 model-settings-model-list-v1.png 原样保留。替换范围仅为模型设置页；编译、列表及步骤/参数编辑不变。生成原件路径与图像校验在本文件末尾记录。

## 原始提示词

```text
Create ONE coherent high fidelity UI review board, not alternate concepts, for the user's approved targeted refinement of the Dr.Octopus browser extension model settings. Three aligned states of the SAME screen side by side; each is exactly 360x600 logical pixels. Board canvas around 1500x900 so Chinese is crisp. Use the attached conversation screenshot of the current black popup and approved old board as visual reference; prioritize current screenshot style. Current date 2026-10-29; no visible dates necessary. Board title: 模型设置 · 模型列表 · 待审阅.
Keep current flat near-black background, charcoal inputs, thin neutral borders, 8-10px corners, white text and muted gray, 14px body. No gradients, no decoration, no nested cards. Header has existing small outlined plug mark and Dr.Octopus, subtitle 浏览器连接 · Google Chrome. Rounded segmented top tabs 连接 / 录制 / 工作流, 工作流 active. Navigation ← 模型设置. Header, tabs, navigation and bottom action footer stay fixed; only body can scroll using slim gray ScrollArea. Do not clip any label behind navbar, leave comfortable 16px horizontal padding.
All three states use identical field order: 提供商 [OpenAI 兼容] read-only; 接口地址 [http://192.0.2.10:4000/v1] synthetic documentation IP; API Key [••••••••••••] with concise helper 密钥仅供本次任务使用。; 模型 row with editable searchable Combobox about 240px wide and a solid white default Button about 72px wide labeled 拉取 with a small refresh icon. The combobox can accept model IDs directly and its chevron opens searchable candidates. Bottom fixed footer has outline 测试连接 and white solid 保存配置. Compact muted text above footer 测试连接可能产生费用。 No warning wall, no auto validation error on untouched empty field.
Left screen subtitle 已选择: combobox [qwen3.5-flash ▾], adjacent active white 拉取. Plenty of compact whitespace below. Bottom 保存配置 enabled. Include an OUTSIDE-frame small component inset labeled 拉取中 illustrating same model row with retained selected value, gray disabled spinner 拉取中 button; do not insert duplicate model field inside the popup.
Middle screen subtitle 搜索模型: editable combobox focused with query qwen, adjacent white 拉取. Popover open UPWARD above model row to fit inside 360x600 without covering fixed footer. Popover aligned to combobox, with crisp compact 32px rows: qwen3.5-flash (selected check), qwen3.5-plus, qwen3.5-turbo. Hover row subtle charcoal shade. A small muted line in popover 未找到时可直接输入模型 ID. Show recognizable editable chevron field and model results; do not introduce separate modal or extra page.
Right screen subtitle 拉取失败 · 可手动填写: combobox retained custom-model ▾, same white 拉取 for explicit retry. A small red inline error under model row: 拉取失败，请重试或手动填写模型 ID。 Only the retrieval message red, the valid manually typed field border stays neutral. 保存配置 remains enabled since manual model value is valid. No giant error card or disabled whole form. No real credentials or user service IP, use only synthetic samples.
This is a revision of one approved interaction plan, NOT three competing designs. All three frames same width, same alignment, consistent font and control sizing. No browser chrome, no device frame, no playback features. Keep title/subtitles outside app screens.
```

## 交互约束

- 表单仍使用 TanStack Form，与现有 Field、错误和提交状态组合。API Key 在模型行之前，只用于本次请求，不持久保存。
- 模型框可输入任意有效模型 ID，也能从拉取结果中搜索选择；返回候选为空或无匹配时使用 Empty，不把请求错误显示为空列表。
- 点击拉取才请求列表；不自动拉取或重试。加载时显示 spinner 并禁用重复点击，不清除当前模型值。接口错误显示字段旁简短提示，不阻止合法手填值保存。
- 地址改变后清空旧候选列表，保留当前手填模型供用户决定；旧请求结果不能覆盖新配置。关闭页面时清理请求所属状态。
- 拉取成功不等于模型可调用；测试连接仍是独立操作。候选数据仅供当前页面选择，不加入持久模型配置。
- 失焦或提交时才显示模型必填错误，首次进入空白字段不标红。自定义值不会因未出现在列表中被拒绝。
- 固定顶部和 footer，只滚动正文；下拉根据可用空间上下定位，结果较多时下拉内部使用一致的 ScrollArea 样式。键盘方向键选择、Enter 确认、Escape 关闭，并保持可见焦点。
- 本轮没有实现生产功能，也未请求任何真实模型列表或编译服务。

## 首稿复核与修订提示词

原图 SHA-256：v1 `ac96872da6d6a439b8e551e287c062bb9ae6fd9173bc104f92962f7d6a2a516e`；v2 `c2615b6ba582adacfc4716cc127431de7d1e826e22fda969ccc2e599efc46dcf`。仓库副本与生成原件字节一致。

v2 来源：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-e7a165b8-b778-45bc-a606-f1c9ba8f1a6e.png。复核确认外框与底部按钮已恢复同高、中性焦点和只读提供商状态；生成图搜索框仍有轻微纵向偏移，实施时浮层须脱离文档流，模型输入框不得因展开而移动，按本文件固定布局约束执行。v2 是待审阅概念稿，不是精确像素或运行验证证据。

首稿 model-settings-model-list-v1.png 已保存原件，来源：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-c1a3d06b-0e8c-4162-b35d-8872d527da84.png。首稿搜索状态使整体框体增高、footer 下移，并出现不符合当前中性灰风格的蓝色焦点。修订以该原图为附件，保持同一方案，修正为上方浮层、固定外框和中性焦点，不增加新功能。

```text
Edit the attached UI review board. Preserve everything except these precise corrections: all THREE popup frames must have IDENTICAL 360x600 logical-pixel dimensions with their TOP and BOTTOM borders aligned. All three footer action button rows must share EXACT same y-coordinate as the left and right screens. The MIDDLE screen currently grows taller when its combobox opens: FIX this. Open the middle model candidate popup UPWARD, anchored immediately ABOVE the model input. The popup may overlay the API Key field as a normal floating popup, but do not move any field, header, footer or frame. The middle model input stays at the same vertical position as left and right inputs. Change blue focus outline to neutral gray/white to match current shadcn neutral ring. Keep existing header, tabs, field labels, synthetic IPs, masked credentials, same readable Simplified Chinese, black/gray palette. Remove the down chevron from all three read-only OpenAI 兼容 provider fields; they are not selectors. Keep model chevrons. Keep the small loading component inset OUTSIDE the left popup. All three 360x600 frames aligned exactly. This is a design review board, no new features.
```
