# 引导式整理视觉稿：来源与完整提示词

2026-10-31，用户授权设计开发文档和视觉稿，明确决策后再实施。三个结果按聊天实际显示顺序对应下列文件；当前均为 pending review，唯一状态登记为 [DESIGN.md](../../../apps/browser-extension/DESIGN.md)。视觉选择不等于实施授权。

方法：内置 image_gen，三次独立调用；未使用用户的 MrToken 配置或测试额度。实际附图为本项目隔离测试的 step-review-light.png（合成数据），只作为品牌、样式与外框参考。参考截图体现的是此前已实现界面，生成结果为设计稿，不是运行截图。目标逻辑尺寸360×600，提示词要求2倍密度；实际生成尺寸在归档检查中记录，不要求按生成图像素照搬字号。

业务与交互契约见 [开发设计](../../architecture/browser-workflow-guided-organization.md)。只对提问主界面的信息层级作三种探索，非三套后端方案。

## 实际显示 1

- 文件：[workflow-guided-question-focus-v1.png](workflow-guided-question-focus-v1.png)
- 原始来源：`C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-bd77b530-a7d5-44f8-b11d-30640c9e71df.png`
- 修订关系：本轮独立首稿，无前序稿；待选择，replacement: none yet。

```text
Create a realistic production-quality UI mockup for the EXISTING Dr.Octopus Chrome browser extension, not a phone app. Reference attachment is actual current popup; preserve its brand mark, compact typography, black-white-gray tokens, 16px content padding, rounded shadcn controls and separator lines. Natural logical viewport 360x600 CSS px, output a sharp 720x1200 image (2x density), ONE single popup screen, edge to edge, no device, no browser chrome, no board title, no outer canvas. Current date 2026-10-31 Asia/Shanghai; no visible timestamp needed. Light theme. Fixed header brand Dr.Octopus + small 浏览器连接 · Google Chrome. Fixed tabs 连接 / 录制 / 工作流 with 工作流 selected; fixed back arrow + title 整理为工作流 navigation. Scroll only content, full-width scrollbar outside padded body when necessary. Fixed bottom footer with outline 稍后处理 left and solid black 确认并继续 right, both on one row. No free-chat composer, no chat send icon, no floating modal, no additional settings tabs. A guided agent question about recorded order search. Single-select radio options; one selected, submission explicit. Text in clear Simplified Chinese, readable 14-16px logical body. One main action, sparse purposeful whitespace; no unnecessary helper copy. Options are exactly 打开对应订单详情, 展示查询结果即可, 暂不确定. Evidence is recorded 第3步 · 打开订单详情. A small optional link 补充说明 may reveal a bounded per-question field later, but no textbox in this frame. Avoid dense nested cards. This is a pending design concept, not running product. Direction: focused question. Center hierarchy within body: small muted 需要你确认 · 1/2; bold prominent 这个流程做到哪里就算完成？; thin compact source reference row 第3步 · 打开订单详情 with chevron; below three generous radio option rows grouped in one subtle rounded outline surface, first option selected. Below group small 补充说明 link. No conversation transcript or stepper.
```

## 实际显示 2

- 文件：[workflow-guided-question-evidence-v1.png](workflow-guided-question-evidence-v1.png)
- 原始来源：`C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-3162a887-44dc-4cbd-baf3-1f44a53a1f11.png`
- 修订关系：本轮独立首稿，无前序稿；待选择，replacement: none yet。

```text
Create a realistic production-quality UI mockup for the EXISTING Dr.Octopus Chrome browser extension, not a phone app. Reference attachment is actual current popup; preserve its brand mark, compact typography, black-white-gray tokens, 16px content padding, rounded shadcn controls and separator lines. Natural logical viewport 360x600 CSS px, output a sharp 720x1200 image (2x density), ONE single popup screen, edge to edge, no device, no browser chrome, no board title, no outer canvas. Current date 2026-10-31 Asia/Shanghai; no visible timestamp needed. Light theme. Fixed header brand Dr.Octopus + small 浏览器连接 · Google Chrome. Fixed tabs 连接 / 录制 / 工作流 with 工作流 selected; fixed back arrow + title 整理为工作流 navigation. Scroll only content, full-width scrollbar outside padded body when necessary. Fixed bottom footer with outline 稍后处理 left and solid black 确认并继续 right, both on one row. No free-chat composer, no chat send icon, no floating modal, no additional settings tabs. A guided agent question about recorded order search. Single-select radio options; one selected, submission explicit. Text in clear Simplified Chinese, readable 14-16px logical body. One main action, sparse purposeful whitespace; no unnecessary helper copy. Options are exactly 打开对应订单详情, 展示查询结果即可, 暂不确定. Evidence is recorded 第3步 · 打开订单详情. A small optional link 补充说明 may reveal a bounded per-question field later, but no textbox in this frame. Avoid dense nested cards. This is a pending design concept, not running product. Direction: evidence first. Under fixed navigation, show one compact reference section with label 相关录制 and two simple rows 2 点击查询 and 3 打开订单详情 (third step gently tinted). Below a separator, show small 需要你确认 · 1/2 then bold 这个流程做到哪里就算完成？. Render the three radio options as clean unboxed rows with light separators; first option selected. Small 补充说明 link. Keep footer fixed and enough breathing space, no chat bubble. All links including 补充说明 must be neutral gray or black, never blue. Keep source context compact enough to fit options and footer; no clipped controls.
```

## 实际显示 3

- 文件：[workflow-guided-question-decisions-v1.png](workflow-guided-question-decisions-v1.png)
- 原始来源：`C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-f2bfddaf-45f1-4722-a1e6-d9d3baffee69.png`
- 修订关系：本轮独立首稿，无前序稿；待选择，replacement: none yet。

```text
Create a realistic production-quality UI mockup for the EXISTING Dr.Octopus Chrome browser extension, not a phone app. Reference attachment is actual current popup; preserve its brand mark, compact typography, black-white-gray tokens, 16px content padding, rounded shadcn controls and separator lines. Natural logical viewport 360x600 CSS px, output a sharp 720x1200 image (2x density), ONE single popup screen, edge to edge, no device, no browser chrome, no board title, no outer canvas. Current date 2026-10-31 Asia/Shanghai; no visible timestamp needed. Light theme. Fixed header brand Dr.Octopus + small 浏览器连接 · Google Chrome. Fixed tabs 连接 / 录制 / 工作流 with 工作流 selected; fixed back arrow + title 整理为工作流 navigation. Scroll only content, full-width scrollbar outside padded body when necessary. Fixed bottom footer with outline 稍后处理 left and solid black 确认并继续 right, both on one row. No free-chat composer, no chat send icon, no floating modal, no additional settings tabs. A guided agent question about recorded order search. Single-select radio options; one selected, submission explicit. Text in clear Simplified Chinese, readable 14-16px logical body. One main action, sparse purposeful whitespace; no unnecessary helper copy. Options are exactly 打开对应订单详情, 展示查询结果即可, 暂不确定. Evidence is recorded 第3步 · 打开订单详情. A small optional link 补充说明 may reveal a bounded per-question field later, but no textbox in this frame. Avoid dense nested cards. This is a pending design concept, not running product. Direction: compact guided decisions. Body begins a small already answered summary row with check icon 订单号：每次运行时填写 and tiny 修改 action. Then a thin divider and small 当前问题 · 1/2. Bold 这个流程做到哪里就算完成？ followed by a small muted inline reference 依据：第3步 · 打开订单详情. Show three compact rounded radio option surfaces, first selected, others neutral. Small 补充说明 link. This is a decision ledger, not a free-chat transcript; no avatars, speech bubbles, timestamps, composer or message input. All links/actions are black or neutral gray, never blue. Keep a compact professional extension rhythm matching the reference.
```

## 归档审阅说明

三图均为选择首项后的示意状态；真实首次进入不默认代用户选择，确认按钮需有效答案才可用。“1/2”只表示当前已生成问题批次，不能暗示总轮次已知。选择“展示查询结果即可”仅明确目标，不授权自动删去录制中的详情步骤；冲突保留为待处理问题，见开发设计。生成稿1的补充说明为蓝色，与既有黑白灰标准不一致，选择该方向后需在细化稿改为中性色；此处记录偏差，不覆盖原图。初次方向稿尚不覆盖深色、长问题、输入说明、错误/恢复和最终预览；选定方向后补齐这些状态并再审阅，不能仅凭本轮图片进入实施。

归档实际尺寸（原图未缩放）：

- workflow-guided-question-focus-v1.png: 971×1619
- workflow-guided-question-evidence-v1.png: 971×1619
- workflow-guided-question-decisions-v1.png: 971×1619

2026-10-31后续选择：用户选择实际显示第2稿。该稿为selected direction，1/3为superseded；上文“均待审阅”是生成时历史，不是当前状态。细化见[本轮来源记录](workflow-guided-refinement-prompts.md)。
