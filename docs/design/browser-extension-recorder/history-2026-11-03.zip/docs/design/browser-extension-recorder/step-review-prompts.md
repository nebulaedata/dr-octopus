# 步骤就地核对视觉稿提示词

日期：2026-10-30。内置 imagegen 生成，参考用户本轮提供的三张深色插件截图及当前 DESIGN.md。全部使用合成订单查询内容，不复制真实充值数据。原始用户截图只作为会话引用；最近图像上下文还包含当时已生成的候选，提示词明确以原始截图作为风格依据。

这是同一已明确方向的三种局部交互细化，尚未选定或实施。权威状态见 [DESIGN.md](../../../apps/browser-extension/DESIGN.md)，交互提案见 [step-review-design.md](step-review-design.md)。顺序按照本轮实际显示顺序登记。

## 实际显示 1：workflow-step-review-evidence-v1.png

[视觉稿](workflow-step-review-evidence-v1.png)。原件位于 C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-adb70bf4-5d2c-4b2d-8489-382944c4467a.png。工具引用最近 3 张图像，包含三张用户截图。

```text
Create realistic production-quality UI mockups matching the attached ORIGINAL Dr.Octopus dark browser-extension screenshots. This is a narrowly scoped redesign of step review, not a new visual style. Current date 2026-10-30. One concept named “证据之后确认”, show TWO adjacent states of the same flow on a single 760x640 review canvas: each actual popup 360x600, narrow gutter. No browser/device chrome. Crisp readable Chinese at 14px body/12px metadata. Near-black background, neutral gray borders, white text, existing rounded shadcn controls; only subtle green for verified checks, no orange/blue accent. Preserve brand Dr.Octopus with small cable icon, subtitle 浏览器连接 · Google Chrome, tabs 连接 / 录制 / 工作流 with 工作流 selected. Header/tab/navigation/footer fixed, only center body scrolls.

LEFT popup workflow overview: back arrow 编辑工作流, trailing 草稿. Name field synthetic “订单查询流程”. Existing tabs 步骤 / 参数, steps selected. Small line “2 项待核对”. Three flat clickable rows with straight Separator siblings, not nested cards: row1 点击查询按钮, metadata 点击 · 页面1, pending badge 待核对; row2 填写订单号, metadata 填写 · 页面1, green check badge 已核对; row3 核对查询结果, metadata 读取结果 · 模型补充 · 页面1, pending badge 待核对. Chevrons on row end. Below rows one success condition field “成功条件 1” value “显示与订单号对应的查询结果”. A SINGLE final checkbox exactly “已核对参数、成功条件”. NO repeated step checkbox list below the rows. Fixed bottom 保存草稿 / 确认并发布 buttons (publish disabled while steps pending).

RIGHT popup step detail: same brand/tabs. Back arrow 步骤详情, trailing badge 待核对. Body has label “步骤 1 · 点击 · 页面 1”; editable 操作说明 field “点击查询按钮”; 目标控件 field “查询按钮”. A compact expanded evidence section titled 来源证据, descriptive line “目标名称不明确，请核对实际控件”, raw evidence line “原始记录：点击控件 · 页面 1”. Below this evidence section on the same scrollable surface place a prominent standard checkbox “已核对该步骤”, checked state sample and a subtle green confirmation check. Small static lock line “执行前需再次确认” is distinct from design-time review. Footer fixed two buttons 取消 outline and 应用修改 solid light. This checkbox is part of local edits applied with 应用修改. No separate review panel elsewhere, no new modal, no batch select all, no claim of actual execution. Render the left pending row and right checked local change as before applying, consistent with applying on footer. Do not use actual payment data or private names from screenshots.
```

## 实际显示 2：workflow-step-review-footer-v1.png

[视觉稿](workflow-step-review-footer-v1.png)。原件位于 C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-bcfdc81a-4c30-41a3-bcf5-914ba4fb42e0.png。工具引用最近 4 张图像，包含三张用户截图。

```text
Create realistic production-quality UI design, ONE independent concept named “底部固定核对”. Use the ORIGINAL user-supplied black Dr.Octopus extension screenshots as style references; keep their established compact dark shadcn style, not the composition of the other generated candidate. Current date 2026-10-30. Show TWO states of one coherent flow side-by-side on a 760x640 canvas, each popup 360x600. No browser chrome, device bezel or extra hero. Body14px metadata12px. Black background, neutral gray surfaces/borders, white text, subtle green only for reviewed. Fixed header/tab/navigation/footer; body-only ScrollArea.

LEFT workflow overview: Dr.Octopus cable glyph header, 浏览器连接 · Google Chrome; 连接 录制 工作流 tabs with 工作流 selected. Back 编辑工作流 and 草稿 badge. Name input 订单查询流程. Steps/Parameters tabs 步骤 参数. Three clickable flat rows with independent straight Separator lines: 1 点击查询按钮, 点击 · 页面1, 待核对 badge; 2 填写订单号, 填写 · 页面1, green-check 已核对 badge; 3 核对查询结果, 读取结果 · 模型补充, 待核对 badge. Small “2 项待核对” context. Below list success-condition input “成功条件 1” value 显示与订单号对应的查询结果 and exactly one aggregate checkbox “已核对参数、成功条件”. Do NOT put a duplicate list of per-step checkboxes below the list. Fixed footer 保存草稿 and disabled 确认并发布.

RIGHT step detail: same header/tabs; back 步骤详情 with pending 待核对 badge. Show title “点击查询按钮”, small 点击 · 页面1 · 来自录制. Compact description “需要核对：目标名称不明确”. Editable target field 目标控件 with 查询按钮. Expanded evidence on plain surface separated by a thin line, heading 来源证据, raw line “点击控件 · 页面1”, explanation “请对照实际操作确认目标”. Keep plenty of empty breathing room after evidence. A small lock line 执行前需再次确认 is informational, separate from review. THE DISTINCTIVE DESIGN: reserve a fixed bottom action area, above the two action buttons, with an unchecked checkbox labeled exactly 已核对该步骤; checkbox remains visible while evidence scrolls. Below that, 取消 outline and 应用修改 solid light. Only this footer contains per-step review, none elsewhere. Applying commits the local review and updates the list badge. Preserve all reference border radii and restrained density; no new page navigation, no stepper, no bulk approval, no fake execution success. All sample content synthetic.
```

## 实际显示 3：workflow-step-review-focus-v1.png

[视觉稿](workflow-step-review-focus-v1.png)。原件位于 C:/Users/zhang/.codex/generated_images/01a18ba8-5a57-7cd2-9535-76de9157c1ae/exec-a4b8a1ee-daba-4116-9418-3fa8314e2fad.png。工具引用最近 5 张图像，包含三张用户截图。

```text
Create a production-quality UI mock, ONE independent concept named “核对优先详情”. Ground the design in the ORIGINAL user-provided Dr.Octopus dark popup screenshots. Preserve that visual system; do not copy the information placement of earlier generated candidates. Current date 2026-10-30. One 760x640 concept canvas with TWO adjacent 360x600 popup states, no device/browser chrome. Black background, neutral gray borders/surfaces, white text, minimal green only for reviewed status. Existing rounded shadcn forms,14px body12px metadata. Fixed brand/tab/nav/footer, center-only ScrollArea.

LEFT overview: cable icon Dr.Octopus, 浏览器连接 · Google Chrome; 连接 录制 工作流 tabs selected工作流. Back 编辑工作流 / 草稿. Name field 订单查询流程. 步骤 参数 segmented tabs. Three simple rows with straight Separator lines: 1 填写订单号, 填写·页面1, green-check 已核对 badge; 2 点击查询按钮, 点击·页面1, 待核对 badge; 3 核对查询结果, 读取结果·模型补充·页面1, 待核对 badge, row3 highlighted neutral hover to imply opening it. Small label “2 项待核对”. After rows, one success condition input “成功条件 1” value 显示与订单号对应的查询结果, then ONLY aggregate checkbox exact text “已核对参数、成功条件”. Absolutely no duplicate per-step checkboxes outside details. Footer 保存草稿 / disabled 确认并发布.

RIGHT model-added step detail: brand andtabs unchanged, back 步骤详情 with 待核对 badge. The distinctive composition prioritizes reading/verification before editing: title 核对查询结果, secondary 读取结果 · 页面1; neutral text 来源：模型补充. A clear compact plain-surface review region with short heading 需要你确认 and text “此读取步骤由模型提出，请确认是否需要。” Below a Separator, heading 建议依据 and text “查询操作之后，检查结果是否符合预期。” Small source note “没有直接录制事件” so proposed evidence is never represented as observed facts. Directly below the evidence in THIS same review region, an unchecked standard checkbox “已核对该步骤”. Below another divider, a COLLAPSED accordion row “修改步骤信息” with a chevron, offering existing edit fields without overwhelming the verification task. Footer fixed 取消 outline / 应用修改 solid light. No execution locks for this read-only extract suggestion, no extra modal, no toolbar wizard, no approval-all. Apply commits both review and any opened edits; cancelling discards local changes. This is a design proposal with synthetic data, not an execution report.
```


## 审阅记录

2026-10-30：用户明确“确认2”，对应实际第二张图片 workflow-step-review-footer-v1.png。DESIGN.md 将其登记为 approved；其余候选及旧分离核对交互登记替代关系。以上原始提示词和图像保留，视觉批准与生产实现分别记录。
