# 录制流程补充稿：完整提示词

> 本文件只记录生成来源与历史审批；当前可用、需修订和弃用状态统一以 [视觉稿登记](../../../apps/browser-extension/DESIGN.md)（apps/browser-extension/DESIGN.md 附录 A）为准。
> 日期：2026-10-27。工具：内置 Image Gen。所有图片为概念稿，五张当前稿已于 2026-10-27 获用户批准，仅限视觉设计；两个已替代初稿不在批准范围；目标尺寸不代表像素验收。原图位于主索引所列生成目录。

## recording-start-v1.png

起始页与允许范围确认；参考 recording-popup-v1。

原始文件：`exec-b6e66e78-cfe1-4451-b916-247e5cf68595.png`。

```text
Create ONE production-quality UI mockup continuing the attached selected Dr.Octopus browser extension popup. Screen: 首次开始录制与范围确认. ONE focused popup at logical 360x560px, crisp 3x rendering. White background, black primary button, thin neutral-gray borders, pale gray surfaces, 12px rounded corners, Chinese system font, logical 14px body and 12px helper, 16px padding. Keep exact header cable icon + Dr.Octopus / 浏览器连接 · Google Chrome with settings gear. Preserve segmented navigation 录制 selected / 工作流 / 连接. Main heading 录制一个新流程 and one-line helper 在网页演示操作，保存后可整理为工作流. Current-page compact row label 起始页面, tab icon, 订单管理 and orders.example.com. Next label 录制范围 followed by selected radio 仅当前标签页 and unselected radio 包含流程打开的新标签页; helper 新页面仅限同一窗口和已允许站点. Below a modest site row 本次允许的站点 / orders.example.com / chevron. Then concise privacy helper 仅记录所选页面，密码和验证码不记录原值. Single BLACK full-width primary 开始录制. Supporting text 开始后可通过网页工具栏暂停或停止. Bottom empty-state text 尚无录制记录 with no giant illustration, and small quiet connection row 本机 Executor 未连接 / 不影响录制. This is explicit scope confirmation before capture, not an installation permission dialog or a stepper. No auto-selected all-tabs, no auto compilation consent, no model requirement, no raw technical IDs. No browser chrome, device frame, presentation background, collage or multiple states. Current date October 27 2026. Accurate Simplified Chinese, readable uncluttered compact extension proportions. This is a visual draft only.
```

## page-recording-toolbar-paused-v1.png

全局暂停录制；参考 page-recording-toolbar-v1。

原始文件：`exec-183cac5f-0a4d-427f-848a-328dd9828b57.png`。

```text
Create ONE production-quality visual draft continuing the attached Dr.Octopus expanded page toolbar. Screen: 全局暂停录制. One desktop webpage viewport 1440x900. White/gray page and extension palette, black primary action, subtle borders and shadow, Chinese system font, thin outline icons. No popup, browser chrome, OS decoration, collage or multiple states. Same fictional order-details page, generic example order ORD-2026-1027 and anonymous sample items; omit customer/contact fields. Focus on a floating toolbar anchored 20px from top-right, approximately 650x76 logical pixels in two compact rows. First row: drag handle, cable icon, neutral gray pause-circle + 已暂停, fixed timer 02:34, 8 步, 2 个页面 dropdown, BLACK triangle icon + 继续录制 button, outlined square icon + 停止保存 button, collapse chevron. Second small gray helper row 暂停期间的操作不会记录. No red recording dot when paused, no active-recording wording, no modal or full-page mask; page remains usable. Do not add discard X or restart actions. Paused state is global across the two participating pages, do not imply per-page pause. Maintain the approved toolbar visual style and appropriate button hit areas. Supporting page sparse, no diagrams or marketing copy. Date anchor October 27 2026. Clear accurate Simplified Chinese. This is a design state mockup, not implementation.
```

## recording-partial-v1.png

已替代初稿；参考 recording-saved-v1。

原始文件：`exec-25121c9a-60c3-45de-9392-6acf90949cea.png`。

```text
Create ONE production-quality Dr.Octopus browser extension UI draft. Reference recording-saved-v1 establishes the saved-result layout; preserve its monochrome style. Screen: 录制中断后的部分保存. One focused 360x560 logical-pixel popup at crisp 3x, no device/browser frame, no collage. Header cable icon, Dr.Octopus / 浏览器连接 · Google Chrome and gear. Segmented navigation 录制 / 工作流 / 连接 with 录制 selected. Content heading 部分记录已保存 beside small outline warning icon, NOT a success checkmark. One modest pale warning-tinted notice 录制已中断, body 订单详情页意外关闭，最后一段操作可能未保存. No claim of exact number of lost events. Name 查询订单状态, metadata 已保存 8 步 · 2 个页面, no continued live timer. Timeline preview with three confirmed rows 填写订单号 / 点击查询 / 打开订单详情 and a fourth clearly distinct dashed gap row 此后的操作未能确认. Below concise reassurance 已保存的内容不会丢失. One black primary button 查看已保存记录, then outlined 重新录制, small helper 重新录制会创建新记录，保留本次内容. Do NOT offer auto-resume, replay or publish incomplete workflow. Avoid raw stack traces and technical IDs. Show a quiet 查看中断详情 disclosure. Use white, neutral gray, black buttons, thin border, 12px rounding, 14px body/12px helper Chinese system typography, one restrained warning tint only. Keep spacing practical and hierarchy calm, not a full-screen error. Current date October 27 2026. Accurate Simplified Chinese. This is a proposed visual state, not tested implementation.
```

## recording-partial-v2.png

历史审批为已批准；当前状态见 [README](README.md)；在 v1 上纠正中断原因及永久保存承诺。

原始文件：`exec-938d377c-3576-4210-8cd7-b2d2f3d7fec8.png`。

```text
Edit the most recent Dr.Octopus partial-save popup mockup only. Preserve its layout, typography, icons, fields, navigation, buttons and all other content exactly. Correct two pieces of copy for architectural accuracy: replace "订单详情页意外关闭，最后一段操作可能未保存。" with "浏览器意外关闭，最后一段操作可能未保存。" because a single participating tab closing need not interrupt the entire recording. Replace "已保存的内容不会丢失。" with "已确认的 8 步已保存在本地。" to avoid promising permanent storage durability. Keep this as one 360x560 logical popup rendered crisply. No additional features or aesthetic changes.
```

## recording-list-v1.png

录制记录列表；参考 recording-popup-v1。

原始文件：`exec-7e502775-6439-4ce8-83b2-8965cfa52324.png`。

```text
Create ONE production-quality UI mockup continuing the attached selected Dr.Octopus extension popup. Screen: 录制记录列表. One popup logical 360x560 at crisp 3x. Preserve original header cable icon, Dr.Octopus / 浏览器连接 · Google Chrome, gear; segmented nav 录制 active / 工作流 / 连接. White background, black primary button, light gray separators, rounded inputs, fine outline icons, Chinese system font, 14px body and 12px metadata, 16px padding. Main title 录制记录, compact outlined + 新录制 button right. A simple search input 搜索录制名称. List with date group 今天 and two rows: 查询订单状态, 8 步 · 2 个页面 · 09:24, neutral 已保存 badge, chevron; 更新客户资料, 已保存 6 步 · 09:10, subtle warning 部分保存 badge, chevron. Date group 昨天 with one row 导出销售报表, 12 步 · 1 个页面 · 16:40, neutral 已整理 badge, chevron. Each row is a flat list item separated by fine rules, not independent thick cards. Do not show a play button because these are recordings, not executable workflows. Do not add filters, mass actions, stats or empty panels for three records. At bottom a quiet row 工作流管理 with chevron linking the existing 工作流 tab, and small helper 录制与工作流分开保存. Keep connection indicator only in nav, do not add a large error block. No browser chrome, device frame, presentation border, collage, illustrations or extra branding. Current date October 27 2026 so 昨天 means October 26. Clear readable Chinese, pragmatic compact interface. Visual draft only.
```

## recording-detail-v1.png

已替代初稿；参考 recording-saved-v1。

原始文件：`exec-a02bf902-65e5-4e7a-ad39-e82eaefe9e77.png`。

```text
Create ONE production-quality UI mockup continuing the attached Dr.Octopus recording-saved screen. Screen: 录制记录详情. ONE popup logical 360x600 at crisp 3x, white/black/gray visual system, fine borders, 12px corners, Lucide-like line icons, 14px body and 12px metadata Chinese system font, 16px padding. No device/browser frame or collage. Top navigation back arrow 录制记录 and ellipsis menu; this is a focused nested detail screen. Heading 查询订单状态 with small pencil edit icon, neutral 已保存 badge, metadata 今天 09:24 · 02:34 · 2 个页面. Label 操作步骤, right small 8 步. Show a clear vertical timeline with group 订单列表 · orders.example.com and four rows 1 打开订单列表, 2 填写订单号 with small 已隐藏输入值, 3 点击「查询」, 4 打开订单详情. Next group 订单详情 · orders.example.com with rows 5 展开订单信息, 6 向下滚动, 7 返回订单列表, 8 停止录制. No raw selectors, screenshot thumbnails, logs or actual personal field values. Subtle note 网页操作记录已保存，尚未整理为工作流. Sticky footer separated by hairline with BLACK full-width 整理为工作流 button. Below button small neutral copy 将使用已配置模型处理脱敏后的操作记录. This screen assumes user configured model and must explicitly click before data is sent; do not show automatic AI progress or play/run actions. Ellipsis contains optional future rename/delete actions but don't render open menu. Keep timeline compact, product-realistic and readable with scrollable body if needed. Current date October 27 2026. This is a design draft, not implemented UI.
```

## recording-detail-v2.png

历史审批为已批准；当前状态见 [README](README.md)；在 v1 上移除将停止录制计为业务步骤的错误。

原始文件：`exec-56645d79-8d67-4439-b4a3-18e4940d53ea.png`。

```text
Edit only two timeline labels in the most recent Dr.Octopus recording-details mockup. Keep every other visual element unchanged. Change step 7 from 返回订单列表 to 刷新订单状态. Change step 8 from 停止录制 to 切回订单列表, with an appropriate simple tab-switch outline icon instead of the stop square. Recording controls themselves must never count as recorded business steps. Keep 8 steps, existing grouping, header, metadata, footer and styling. No other additions or changes.
```
