# 模型设置：连接反馈与密钥保存

日期：2026-10-29。用户已确认修正方案：测试连接留在当前设置页，使用基于 Alert 的成功/失败 toast；保存配置时保存当前浏览器的接口密钥，重入后可复用。首轮只交付视觉稿；用户随后明确修改后实施，现已按 v3 接入，当前状态以 DESIGN.md 和验证矩阵为准。审阅状态以 [DESIGN.md](../../../apps/browser-extension/DESIGN.md) 为准。

## 来源与范围

- 使用内置 Image Gen，以已归档的 [模型列表 v2](model-settings-model-list-v2.png) 为图像附件，延续既有黑灰配色、Combobox、拉取按钮和固定外框。
- 输出为 `model-settings-connection-feedback-v1.png`：同一设置页的连接成功、连接失败、密钥已保存三个状态，以及测试中按钮局部示意，不是三套备选方案。
- 用户截图中的任务页只用于确认问题；新稿不沿用该跳转，不把连接测试解释为录制整理。
- 服务地址使用文档示例 IP，密钥为占位圆点；全部为合成视觉稿，不是运行证据。

## 原始提示词

```text
Create ONE high fidelity three-state review board for a precise refinement of the attached Dr.Octopus browser extension settings design. This is one agreed interaction design, NOT three alternative concepts. Output about 1536x960, three identical 360x600 logical-pixel popup frames side by side, proportional scaling only. All frame tops/bottoms, header, tabs, navigation, fields and footer button baselines MUST align exactly. Current date 2026-10-29, no visible dates needed. Board title outside frames: 模型设置 · 连接反馈与密钥保存 · 待审阅. Each frame caption outside: 连接成功 / 连接失败 / 再次进入设置.
Use attached image only for existing design language: near-black background, dark charcoal fields, neutral gray thin borders, restrained rounded corners, white text, muted readable gray Chinese, 14px body and 12px labels, no gradients or decoration. Preserve existing Dr.Octopus plug brand tile, subtitle 浏览器连接 · Google Chrome, rounded segmented tabs 连接 / 录制 / 工作流 with 工作流 selected. Navigation is ALWAYS ← 模型设置. Never show a separate testing or compilation page. Header, tabs, navigation and footer remain fixed; body only may scroll.
All screens show the SAME compact form: 提供商 read-only [OpenAI 兼容] without chevron; 接口地址 [http://192.0.2.10:4000/v1] synthetic address; API Key row; 模型 row consisting of editable combobox [qwen3.5-flash ▾] and adjacent solid white 拉取 button with refresh icon. Both values and positions must remain unchanged between success/failure. Do not open model dropdown in this board. No real keys, no private IP or customer data.
LEFT success state: API Key is a password input with round masked bullets representing a newly entered key. Small helper 保存配置后保留在此浏览器. A compact shadcn Alert-based toast is floating just ABOVE the fixed footer, inset16px, rounded8px, muted dark green tinted surface/border, green check-circle icon and readable pale green text: 连接成功 · 1.2 秒. Small close x at right. It is an overlay, never a new page or a large banner, no layout shift, never covers footer buttons or model field. No claim configuration automatically saved. Footer left outline button 测试连接, right white solid button 保存配置. Small muted cost hint 测试连接可能产生费用 remains unobscured if space permits, otherwise omit it on the static success frame.
MIDDLE failure state: IDENTICAL frame/form geometry and typed key bullets preserved. Alert toast at EXACT same position above footer, muted dark red tint, red x-circle icon, readable red text 鉴权失败，请检查 API Key and dismiss x. Red limited to toast; do not mark model input invalid or clear any values. Footer buttons unchanged, 测试连接 available for explicit retry. Do not use 整理未完成 or show workflow progress.
RIGHT persisted/reopened state: same settings page, same endpoint/model. API Key field is a compact neutral bordered read-only row: lock icon and 已保存 aligned left, two small ghost text actions 更换 and 清除 aligned right. NO password dots and NO real key in this saved-state row. Small helper 保存到此浏览器. No permanent green success badge and no toast in this resting state. Footer test/save buttons at identical positions, test enabled. No new toggle, no remember checkbox, no promise of encryption.
Add a single small component-state inset OUTSIDE below the frames showing the outline test button with spinner and text 测试中, annotated 原页等待，不跳转. Keep this outside the popups, not a fourth alternative.
Minimal copy. No encryption marketing, no recording permission checkbox (this is settings entered from workflow list), no playback button, no modal, no sidebar, no new navigation. Exact copy illustrative but maintain meaning; prioritize approved palette/layout, coherent success/failure colors, legible CJK and fixed frame.
```

## 已确认方案与视觉细化

生成原件：`C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-bd9b94f9-03e8-4586-b429-78b4b9b26210.png`。已原样复制到本目录，原文件保留。复核三屏表单与底栏对齐、toast 未遮挡按钮，成功/失败颜色有明确区分；图像仍属待审阅视觉稿，不是实现或运行验收证据。

- 测试连接使用当前地址、模型及有效密钥发起一次最小模型请求，验证鉴权和真实模型响应。拉取目录成功不能代替模型调用成功。
- 测试始终留在设置页，保留表单与正文滚动位置；不读取录制、不创建工作流、不覆盖最近整理任务。测试不自动保存配置；开始整理继续由独立明确动作触发。
- 测试中按钮显示 spinner 并阻止重复提交；配置改变或离开设置页取消本页测试，旧回包不更新新配置的反馈。不自动重试。
- 应用层封装 Alert toast，不直接修改共享 Alert 源码。用户随后明确要求 Toast 放到顶部：在设置页固定导航下方悬浮，不挤动表单、不遮挡返回导航，随正文滚动仍保持固定；成功使用 success 色和 Check 图标，约 4 秒后关闭；失败使用 destructive 色和错误图标，保留关闭按钮。提供对应可访问播报，悬停/键盘聚焦时暂停自动消失。原始提示词的 footer 上方定位仅为历史来源，已失效。
- 成功显示连接成功与耗时；失败区分鉴权、模型不可用、超时和服务不可达，不回显提供商原始响应或凭据。静态示例文本可调整，仍按根目录文案弹性规则。
- 保存配置同时保存该提供商和规范化接口地址下的密钥到当前浏览器；重启后可复用，不进入同步、日志、工作流或导出数据。存储仅向受信扩展上下文开放，不宣称系统密钥库级加密。
- 设置页重新进入显示“已保存”和更换/清除操作，不把秘密明文或伪造圆点回填进可编辑表单。模型目录、测试和整理优先使用本次输入，否则使用当前接口已保存的密钥；接口变化不能自动将旧密钥发送到新地址。
- 更换进入新密钥输入态，保存才替换旧凭据；放弃未保存更换不清除原凭据。清除是明确独立操作，成功后恢复未配置状态；关闭或失败不得伪报已清除。
- 首轮出稿时尚未实施；后续已按用户定向修改及实施授权接入，并补充持久重入、endpoint 隔离、失败原地停留和旧回包隔离回归。

## v2：仅修订顶部位置

用户反馈：“Toast 放在顶部，其余确认”。v1 的 Toast 位置标记为 revision required，其余范围已确认；v2 只审阅顶部定位，不重复审阅已确认的颜色、表单及密钥状态。图像原件不覆盖。未开始功能实施。

```text
Edit the attached Dr.Octopus model-settings three-state UI review board with ONE requested change only: move both success and failure Alert-based toasts from above the footer to the TOP of the settings content, immediately BELOW the fixed “← 模型设置” navigation divider, inset 16 logical pixels horizontally and about 8 logical pixels below the divider. They are floating overlays above the form, not in document flow; do NOT push fields down or move any header, navigation, field, model row, footer button, or popup boundary. It is acceptable for the toast to temporarily overlay the read-only provider row, but never cover the navigation/back control. Maintain exactly the same toast green/red colors, text, icons, close buttons and dimensions. Erase the old bottom toasts and restore plain background there. The third saved-key resting screen has no toast and must remain unchanged. All other design details are already explicitly approved by the user: preserve them. Keep three equally sized 360x600 logical-pixel frames, same aligned baselines, same black/gray styling and synthetic data. Outside-board title: 模型设置 · 顶部连接提示 · 待审阅. Keep the existing outside-frame testing-spinner inset. No other changes. Current date 2026-10-29, no visible dates. This revision is solely top positioning, not a new visual direction.
```

## v3 定向修正与实施授权

用户随后明确“修改后开始实施”，不再要求重复审批。v2 生成误将表单下移，并将已保存密钥行改为密码输入；已归档原件、标记 superseded，不作为目标。v3 从 v1 原图重新定向编辑，仅将两条 toast 移至导航下方悬浮，保留已保存/更换/清除状态及原表单坐标。依据用户定向修改和实施授权作为 approved 目标，不声称用户逐像素审阅过 v3。

v2 原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-510a5636-4fcf-48d8-9d3b-3c4c905bc7ea.png。
v3 原件：C:/Users/zhang/.codex/generated_images/01a17899-502e-7e21-b043-aa97664233cf/exec-3dc9ee37-2401-4168-af84-6bb660c8f1ad.png。

```text
Edit the attached ORIGINAL v1 board very conservatively. Move the GREEN success toast and RED failure toast to overlap the provider field near the top of each respective popup: their top edge at about 295 image pixels, below navigation divider at 275. They must FLOAT ON TOP of the existing read-only provider field, occluding it temporarily. DO NOT move any form fields down. Explicitly preserve every form field coordinate and footer coordinate of this source image. Remove both old bottom toasts leaving black empty space above footer. The entire THIRD SCREEN must be preserved unchanged, especially its key row showing a LOCK icon, 已保存, 更换, 清除; absolutely no password bullets in that third-screen row. Preserve all text, colors and layout otherwise. Title outside frames: 模型设置 · 顶部连接提示. All three popup frames unchanged size. No extra footer content. User approved every other detail; this is ONLY a relocation of two floating toasts.
```
